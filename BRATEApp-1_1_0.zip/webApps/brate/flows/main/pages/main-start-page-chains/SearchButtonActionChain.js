define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SearchButtonActionChain extends ActionChain {

    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const params = {};

      const addIfValid = (key, value) => {
        if (value !== undefined && value !== null && value !== '') {
          params[key] = value;
        }
      };

      const formatDateOnly = (dateStr) => {
        if (!dateStr) return null;
        return dateStr.split('T')[0];
      };

      addIfValid('p_bank_account_name_alt', $variables.bankAccountNameVar);
      addIfValid('p_bank_account_num', $variables.bankAccountVar);
      addIfValid('p_bank_name', $variables.bankNameVar);
      addIfValid('p_stmt_date_from', formatDateOnly($variables.fromDateVar));
      addIfValid('p_stmt_date_to', formatDateOnly($variables.toDateVar));

      const response = await Actions.callRest(context, {
        endpoint: 'hdrlindata/get',
        uriParams: params,
      });

      if (response.ok) {
        $variables.hdrlinedataADP.data = response.body.items;
      }
    }
  }

  return SearchButtonActionChain;
});
