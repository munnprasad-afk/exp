define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (ActionChain, Actions, ActionUtils) => {
  'use strict';

  class refreshAmountActionChain extends ActionChain {

    async run(context, { event, originalEvent }) {
      const { $page, $variables } = context;

      const statementAmt = Math.round((parseFloat($variables.statementLineAmountVar) || 0) * 100) / 100;
      const rows = Array.isArray($variables.distributionRows)
        ? $variables.distributionRows
        : [];

      const totalDistributed = Math.round(
        rows.reduce((sum, row) => sum + (parseFloat(row.amount) || 0), 0) * 100
      ) / 100;

      const remaining = Math.round((statementAmt - totalDistributed) * 100) / 100;

      $variables.availableAmountVar = String(remaining);
    }
  }

  return refreshAmountActionChain;
});
