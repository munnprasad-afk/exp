define([
  'vb/action/actionChain',
  'vb/action/actions',
], (ActionChain, Actions) => {
  'use strict';

  class downloadDocActionChain extends ActionChain {

    async run(context, { awaitingDocId, fileName }) {

      try {

        const response = await Actions.callRest(context, {
          endpoint: 'getDocument/get',
          queryParams: {
            'awaiting_doc_id': awaitingDocId,
          },
          uriParams: {
            'awaiting_doc_id': awaitingDocId,
          },
        });

        const doc = response.body || response;

        if (!doc || !doc.document_base64) {
          throw new Error('Document content not found');
        }

        const base64 = doc.document_base64.replace(/\s/g, '');

        const name = (doc.file_name || fileName || 'document').toLowerCase();

        const mimeMap = {
          '.pdf': 'application/pdf',
          '.jpg': 'image/jpeg',
          '.jpeg': 'image/jpeg',
          '.png': 'image/png',
          '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          '.xls': 'application/vnd.ms-excel',
          '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          '.csv': 'text/csv',
          '.txt': 'text/plain'
        };

        let mimeType = 'application/octet-stream';

        for (const ext in mimeMap) {
          if (name.endsWith(ext)) {
            mimeType = mimeMap[ext];
            break;
          }
        }

        const byteCharacters = atob(base64);
        const byteNumbers = new Uint8Array(byteCharacters.length);

        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }

        const blob = new Blob([byteNumbers], {
          type: mimeType
        });

        const blobUrl = window.URL.createObjectURL(blob);

        const a = document.createElement('a');
        a.href = blobUrl;
        a.download = doc.file_name || fileName || 'document';

        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);

        window.URL.revokeObjectURL(blobUrl);

      } catch (error) {

        await Actions.fireNotificationEvent(context, {
          summary: 'Download Error',
          message: error.message || JSON.stringify(error),
          type: 'error',
          displayMode: 'transient'
        });

      }
    }
  }

  return downloadDocActionChain;
});