define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TableBeforeRowEditChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.accept
     * @param {object} params.rowContext
     * @param {any} params.rowKey
     * @param {number} params.rowIndex
     * @param {any} params.rowData
     */
    async run(context, { event, accept, rowContext, rowKey, rowIndex, rowData }) {
      const { $page, $flow, $application, $constants, $variables, $event } = context;


      const data = event.detail.rowContext.item.data;

      if (!data || data.line_id === null || data.line_id === undefined) {
        if (typeof accept === 'function') {
          accept(Promise.reject());
        } else {
          event.preventDefault();
        }
        $variables.currentLineBuffer = {};
        $variables.preEditRow = {};
        await Actions.fireNotificationEvent(context, {
          summary: 'Line Not Editable',
          message: 'This line has no Line Id and cannot be edited.',
          type: 'error',
          displayMode: 'transient',
        });
        return;
      }

      $variables.currentLineBuffer = JSON.parse(JSON.stringify(data));
      $variables.preEditRow = JSON.parse(JSON.stringify(data));

   
    }
  }

  return TableBeforeRowEditChain;
});
