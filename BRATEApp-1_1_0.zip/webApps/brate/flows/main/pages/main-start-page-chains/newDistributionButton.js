define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (ActionChain, Actions, ActionUtils) => {
  'use strict';

  class newDistributionButton extends ActionChain {

    async run(context, { event, originalEvent }) {
      const { $page, $variables } = context;

      const currentData = Array.isArray($variables.distributionRows)
        ? $variables.distributionRows
        : [];

      const newRow = {
        selected: [],
        offsetDist: '',
        offsetRaw: '',
        amount: null,
        description: '',
        status: 'Awaiting Approval',
      };

      $variables.distributionRows = currentData.concat([newRow]);

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.addDistributionADP,
      });
    }
  }

  return newDistributionButton;
});
