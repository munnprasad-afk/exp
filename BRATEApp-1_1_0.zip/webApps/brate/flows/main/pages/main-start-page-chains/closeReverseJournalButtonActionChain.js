define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class closeReverseJournalButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const reverseJournalDialogClose = await Actions.callComponentMethod(context, {
        selector: '#reverseJournalDialog',
        method: 'close',
      });
    }
  }

  return closeReverseJournalButtonActionChain;
});
