define([
  'vb/action/actionChain',
  'vb/action/actions',
], (ActionChain, Actions) => {
  'use strict';

  class SubmitReversalButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $variables } = context;

      const reason = ($variables.reversalReasonVar || '').trim();
      if (reason === '') {
        await Actions.fireNotificationEvent(context, {
          summary: 'Reversal Reason Required',
          message: 'Enter a JE Reversal Reason before submitting.',
          type: 'warning',
          displayMode: 'transient',
        });
        return;
      }

      const lineId = Number($variables.lineIdVar);
      if (!lineId || isNaN(lineId)) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Line Id Not Available',
          message: 'No valid Line Id for this reversal request.',
          type: 'error',
          displayMode: 'transient',
        });
        return;
      }

      const closeDialog = () => Actions.callComponentMethod(context, {
        selector: '#reverseJournalDialog',
        method: 'close',
      });

      $variables.reversalInProgress = true;

      try {
        const auditResponse = await Actions.callRest(context, {
          endpoint: 'addJeRevAudit/get',
          body: {
            line_id: lineId,
            reversal_reason: reason,
            status: 'REVERSAL_REQUESTED',
            created_by: $variables.createdByUser,
          },
        });

        const auditBody = (auditResponse && auditResponse.body) || {};

        if (!auditResponse.ok || !(auditBody.rows_inserted > 0)) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Reversal Request Failed',
            message: auditBody.message || 'Reversal audit record could not be inserted.',
            type: 'error',
            displayMode: 'transient',
          });
          await closeDialog();
          return;
        }

        const reversalResponse = await Actions.callRest(context, {
          endpoint: 'reversal/postIcApiIntegrationV1FlowsRestTRANSACTIONUIJEREVERSAL1_0Reversal',
          body: {
            LINE_ID: String(lineId),
            REVERSAL_REASON: reason,
            STATUS: 'REVERSAL_REQUESTED',
            CREATED_BY: $variables.createdByUser,
          },
        });

        const reversalBody = (reversalResponse && reversalResponse.body) || {};

        if (!reversalResponse.ok || reversalBody.status !== 'S') {
          await Actions.fireNotificationEvent(context, {
            summary: 'Reversal Request Failed',
            message: reversalBody.message || 'Reversal integration returned an error.',
            type: 'error',
            displayMode: 'transient',
          });
          await closeDialog();
          return;
        }

        await closeDialog();

        await Actions.fireNotificationEvent(context, {
          summary: 'Reversal Requested',
          message: 'Journal Entry Reversal is requested successfully.',
          type: 'confirmation',
          displayMode: 'transient',
        });

        await Actions.callComponentMethod(context, {
          selector: '#reverseJournaSubmittedlDialog',
          method: 'open',
        });

        await Actions.fireDataProviderEvent(context, {
          refresh: null,
          target: $variables.hdrlinedataSDP,
        });

      } catch (error) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Reversal Request Error',
          message: (error && error.message) ? error.message : 'Unexpected error.',
          type: 'error',
          displayMode: 'transient',
        });
        await closeDialog();
      } finally {
        $variables.reversalInProgress = false;
      }
    }
  }

  return SubmitReversalButtonActionChain;
});
