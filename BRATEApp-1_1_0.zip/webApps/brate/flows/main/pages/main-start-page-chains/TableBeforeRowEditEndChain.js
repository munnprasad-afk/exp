define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TableBeforeRowEditEndChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.accept
     * @param {any} params.setUpdatedItem
     * @param {object} params.rowContext
     * @param {any} params.cancelEdit
     * @param {any} params.rowKey
     * @param {number} params.rowIndex
     * @param {any} params.rowData
     */
    async run(context, { event, accept, setUpdatedItem, rowContext, cancelEdit, rowKey, rowIndex, rowData }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // User cancelled the edit (Esc) - discard, buffer nothing
      if (cancelEdit) {
        $variables.currentLineBuffer = {};
        $variables.preEditRow = {};
        return;
      }

      const cleanData = JSON.parse(JSON.stringify($variables.currentLineBuffer || {}));
      const preEdit = $variables.preEditRow || {};

      // Guard: empty buffer (edit-end fired without a matching edit-start)
      if (Object.keys(cleanData).length === 0) {
        $variables.preEditRow = {};
        return;
      }

      // Journal Created lines are not editable - discard any buffered state
      if (cleanData.gl_status === 'Journal Created'
        || preEdit.gl_status === 'Journal Created') {
        $variables.currentLineBuffer = {};
        $variables.preEditRow = {};
        return;
      }

      // The buffer key must be the data provider's row key.
      // With keyAttributes: 'line_id' on hdrlinedataSDP, rowKey IS line_id.
      // NEVER write the key into cleanData.line_id - the record's own
      // line_id is the source of truth for the update endpoint.
      const key = (rowKey !== undefined && rowKey !== null) ? rowKey : cleanData.line_id;

      if (key === undefined || key === null) {
        $variables.currentLineBuffer = {};
        $variables.preEditRow = {};
        return;
      }

      // Cleared inputs can leave null/undefined; force the editable fields
      // to exist explicitly so the PATCH body always carries them.
      cleanData.classification = (cleanData.classification === undefined || cleanData.classification === null)
        ? '' : cleanData.classification;
      cleanData.je_grouping = (cleanData.je_grouping === undefined || cleanData.je_grouping === null)
        ? '' : cleanData.je_grouping;

      // Push the edited row into the BufferingDataProvider's buffer
      await $page.variables.hdrlinedataBDP.instance.updateItem({
        data: cleanData,
        metadata: {
          key: key
        }
      });

      // Auto-select the line when classification or je_grouping changed
      const changed =
        cleanData.classification !== (preEdit.classification || '')
        || cleanData.je_grouping !== (preEdit.je_grouping || '');

      if (changed) {
        const selected = Array.isArray($variables.selectedLines)
          ? $variables.selectedLines.slice()
          : [];
        const idx = selected.findIndex((l) => l.line_id === key);
        const entry = {
          line_id: key,
          je_grouping: cleanData.je_grouping,
          bank_account_num: cleanData.bank_account_num,
        };
        if (idx > -1) {
          selected[idx] = entry;
        } else {
          selected.push(entry);
        }
        $variables.selectedLines = selected;
      }

      $variables.currentLineBuffer = {};
      $variables.preEditRow = {};
    }
  }

  return TableBeforeRowEditEndChain;
});