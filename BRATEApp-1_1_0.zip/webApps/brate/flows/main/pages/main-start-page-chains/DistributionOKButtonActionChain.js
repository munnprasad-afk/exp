define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class DistributionOKButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const ojDialog18465089721Close = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-1846508972-1',
        method: 'close',
      });
    }
  }

  return DistributionOKButtonActionChain;
});
