define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class openReversalActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     * @param {any} params.key
     * @param {number} params.index
     * @param {any} params.current
     */
    async run(context, { event, originalEvent, key, index, current }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      if (current && current.row) {
        $variables.lineIdVar = (current.row.line_id != null) ? String(current.row.line_id) : ' ';
        $variables.statementLineAmountVar = (current.row.entry_amt != null) ? String(current.row.entry_amt) : '';
      }
      $variables.reversalReasonVar = '';

      const reverseJournalDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#reverseJournalDialog',
        method: 'open',
      });
    }
  }

  return openReversalActionChain;
});
