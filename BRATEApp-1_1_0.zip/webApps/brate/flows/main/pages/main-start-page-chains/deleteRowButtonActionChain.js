define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (ActionChain, Actions, ActionUtils) => {
  'use strict';

  class deleteRowButtonActionChain extends ActionChain {

    async run(context, { event, originalEvent }) {
      const { $page, $variables } = context;

      const currentData = Array.isArray($variables.distributionRows)
        ? $variables.distributionRows
        : [];

      const remaining = currentData.filter((row) =>
        !(Array.isArray(row.selected) && row.selected.includes('checked'))
      );

      if (remaining.length === currentData.length) {
        await Actions.fireNotificationEvent(context, {
          summary: 'No Rows Selected',
          message: 'Select at least one row using the checkbox before deleting.',
          type: 'warning',
          displayMode: 'transient',
        });
        return;
      }

      $variables.distributionRows = remaining;

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.addDistributionADP,
      });
    }
  }

  return deleteRowButtonActionChain;
});
