define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class resetButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$variables.toDateVar',
    '$variables.glStatusVar',
    '$variables.fromDateVar',
    '$variables.bankNameVar',
    '$variables.bankAccountVar',
    '$variables.bankAccountNameVar',
  ],
      });

      $variables.columnViewVar = 'default';
    }
  }

  return resetButtonActionChain;
});
