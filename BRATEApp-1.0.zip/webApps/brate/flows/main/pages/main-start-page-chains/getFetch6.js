define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getFetch6 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{hookHandler:'vb/RestHookHandler'}} params.configuration
     */
    async run(context, { configuration }) {
      const { $page, $flow, $application, $constants, $variables } = context;
	  
	  	  	  if (configuration.hookHandler.context.fetchOptions.filterCriterion) {
				          const callRestEndpoint1 = await Actions.callRest(context, {
          endpoint: ':GljeOutputString/get',
		  responseType: 'getjeOutputString',
		  hookHandler: configuration.hookHandler,
		   requestType: 'json',
          uriParams: {
            q: "{\"je_output_string\": {\"$instr\": \""  +
            configuration.hookHandler.context.fetchOptions.filterCriterion.text +                         
            "\"}}"
          },
        });
        return callRestEndpoint1; 
			  }
	  
	  
   else{
      const callRestEndpoint1 = await Actions.callRest(context, {
        endpoint: 'GljeOutputString/get',
        responseType: 'getjeOutputString',
        hookHandler: configuration.hookHandler,
        requestType: 'json',
      });

      return callRestEndpoint1;
     }
	  


    }
  }

  return getFetch6;
});
