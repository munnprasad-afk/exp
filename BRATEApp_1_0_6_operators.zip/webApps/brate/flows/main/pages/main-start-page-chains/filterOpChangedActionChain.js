define([
  'vb/action/actionChain',
  'vb/action/actions',
], (
  ActionChain,
  Actions
) => {
  'use strict';

  const TO_VARS = {
    amountVar: 'amountToVar',
    classificationruleidVar: 'classificationruleidToVar',
    classificationruleversionVar: 'classificationruleversionToVar',
    closingbalanceVar: 'closingbalanceToVar',
    exchangeamountVar: 'exchangeamountToVar',
    exchangerateVar: 'exchangerateToVar',
    headeridVar: 'headeridToVar',
    journalizationruleidVar: 'journalizationruleidToVar',
    journalizationruleversionVar: 'journalizationruleversionToVar',
    lastupdatedbyVar: 'lastupdatedbyToVar',
    linenumberVar: 'linenumberToVar',
    lineidVar: 'lineidToVar',
    numberofcreditentriesVar: 'numberofcreditentriesToVar',
    numberofdebitentriesVar: 'numberofdebitentriesToVar',
    openingbalanceVar: 'openingbalanceToVar',
    reconciledamountVar: 'reconciledamountToVar',
    trxentrynoVar: 'trxentrynoToVar',
    fromDateVar: 'toDateVar',
    exchangeratedateVar: 'exchangeratedateToVar',
    lastupdatedateVar: 'lastupdatedateToVar',
  };

  const FIELDS = [
    'bankAccountNameVar',
    'bankAccountVar',
    'bankNameVar',
    'glStatusVar',
    'amountVar',
    'amountcurrencyVar',
    'baicodeVar',
    'cashglaccountVar',
    'classificationVar',
    'classificationruleidVar',
    'classificationrulenameVar',
    'classificationruleversionVar',
    'closingbalanceVar',
    'companycodeVar',
    'customerreferenceVar',
    'descriptionVar',
    'domaincodeVar',
    'exchangeamountVar',
    'exchangecurrencyVar',
    'exchangerateVar',
    'familycodeVar',
    'filenameVar',
    'glaccountVar',
    'glflagVar',
    'headermessageVar',
    'headeridVar',
    'jegroupVar',
    'jereversalreasonVar',
    'jereversalstatusVar',
    'journalizationruleidVar',
    'journalizationrulenameVar',
    'journalizationruleversionVar',
    'lastupdatedbyVar',
    'ledgernameVar',
    'linemessageVar',
    'linenumberVar',
    'lineidVar',
    'manualoverrideVar',
    'numberofcreditentriesVar',
    'numberofdebitentriesVar',
    'offseticcreditVar',
    'offseticdebitVar',
    'offsetledgerVar',
    'openingbalanceVar',
    'oraclecetransferVar',
    'reconciledamountVar',
    'reconciliationstatusVar',
    'statementnumberVar',
    'subfamilycodeVar',
    'transactiontypeVar',
    'trxentrynoVar',
    'fromDateVar',
    'exchangeratedateVar',
    'lastupdatedateVar',
  ];

  const BLANK_OPS = ['NULL', 'NNULL'];

  class filterOpChangedActionChain extends ActionChain {

    async run(context, { event }) {
      if (!event || !event.detail || !BLANK_OPS.includes(event.detail.value)) {
        return;
      }

      const origin = event.target || event.currentTarget;
      const host = origin && typeof origin.closest === 'function' ? origin.closest('[data-field]') : null;
      const field = host ? host.getAttribute('data-field') : null;

      if (!field || !FIELDS.includes(field)) {
        return;
      }

      const toReset = ['$variables.' + field];
      if (TO_VARS[field]) {
        toReset.push('$variables.' + TO_VARS[field]);
      }

      await Actions.resetVariables(context, {
        variables: toReset,
      });
    }
  }

  return filterOpChangedActionChain;
});
