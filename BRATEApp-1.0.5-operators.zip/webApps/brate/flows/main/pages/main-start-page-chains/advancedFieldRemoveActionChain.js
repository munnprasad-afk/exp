define([
  'vb/action/actionChain',
  'vb/action/actions',
], (ActionChain, Actions) => {
  'use strict';

  const DATE_TO_VARS = {
    exchangeratedateVar: 'exchangeratedateToVar',
    lastupdatedateVar: 'lastupdatedateToVar',
  };

  class advancedFieldRemoveActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     */
    async run(context, { event }) {
      const { $variables } = context;

      const origin = (event && (event.target || event.currentTarget)) || null;
      const host = (origin && typeof origin.closest === 'function')
        ? origin.closest('[data-field]')
        : null;
      const field = host ? host.getAttribute('data-field') : null;

      if (!field) {
        return;
      }

      const current = $variables.advancedSearchVar || {};

      if (!Object.prototype.hasOwnProperty.call(current, field)) {
        return;
      }

      const next = Object.assign({}, current);
      next[field] = false;
      $variables.advancedSearchVar = next;

      const toReset = ['$variables.' + field, '$variables.' + field + 'Op'];
      if (DATE_TO_VARS[field]) {
        toReset.push('$variables.' + DATE_TO_VARS[field]);
      }

      await Actions.resetVariables(context, {
        variables: toReset,
      });
    }
  }

  return advancedFieldRemoveActionChain;
});
