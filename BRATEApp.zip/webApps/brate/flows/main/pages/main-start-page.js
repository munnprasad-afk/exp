define([], () => {
  'use strict';

  class PageModule {


formatDate(dateStr) {
  if (!dateStr) return '';
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(dateStr));
  if (!m) return '';
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return `${m[3]}-${monthNames[Number(m[2]) - 1]}-${m[1]}`;
}

  }
  
  return PageModule;
});
