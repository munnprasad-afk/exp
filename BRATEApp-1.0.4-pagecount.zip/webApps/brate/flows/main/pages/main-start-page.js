define([], () => {
  'use strict';

  class PageModule {

    constructor(context) {
      this.eventHelper = context.getEventHelper();

      this.hdrRequestPaginate = (configuration, options) => {
        const url = configuration.url;
        configuration.url = url + (url.indexOf('?') >= 0 ? '&' : '?')
          + 'limit=' + encodeURIComponent(options.size) + '&offset=' + encodeURIComponent(options.offset);
        return configuration;
      };

      this.hdrResponsePaginate = (result) => {
        const tr = {};
        if (result && result.body) {
          tr.data = result.body.items;
          tr.hasMore = !!result.body.hasMore;
        } else {
          tr.hasMore = false;
        }
        return tr;
      };

      this.hdrResponseBody = (result) => {
        const body = result ? result.body : undefined;
        if (!body || !Array.isArray(body.items) || body.offset === undefined) {
          return body;
        }
        const size = Number(body.limit) || 25;
        const offset = Number(body.offset) || 0;
        const count = body.count != null ? Number(body.count) : body.items.length;
        if (count === 0 && offset > 0) {
          return body;
        }
        const total = count > 0 ? Number(body.items[0].total_records) || 0 : 0;
        this.eventHelper.fireCustomEvent('hdrFetchStats', {
          stats: {
            totalRecords: total,
            loadedCount: offset + count,
            page: count > 0 ? Math.floor(offset / size) + 1 : 0,
            totalPages: Math.ceil(total / size),
          },
        });
        return body;
      };
    }

    formatDate(dateStr) {
      if (!dateStr) return '';
      const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(dateStr));
      if (!m) return '';
      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      return `${m[3]}-${monthNames[Number(m[2]) - 1]}-${m[1]}`;
    }
  }

  return PageModule;
});
