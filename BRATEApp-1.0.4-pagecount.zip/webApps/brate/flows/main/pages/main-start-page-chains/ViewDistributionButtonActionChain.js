define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ViewDistributionButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     * @param {any} params.key
     * @param {number} params.index
     * @param {any} params.current
     */
    async run(context, { event, originalEvent, key, index, current }) {
      const { $page, $flow, $application, $constants, $variables } = context;

//console.log("=================START============"); 
//console.log(current.row.entry_amt); 
//console.log("=================END============"); 

$variables.lineIdVar =  current.row.line_id;

      $variables.statementLineAmountVar = current.row.entry_amt;


      const ojDialog18465089721Open = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-1846508972-1',
        method: 'open',
      });

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.distributionDataSDP,
      });

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.listApprovedDocumentsSDP,
      });

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.listDocumentsSDP,
      });
    }
  }

  return ViewDistributionButtonActionChain;
});
