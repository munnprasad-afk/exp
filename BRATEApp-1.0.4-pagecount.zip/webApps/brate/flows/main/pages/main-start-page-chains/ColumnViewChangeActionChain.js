define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (ActionChain, Actions, ActionUtils) => {
  'use strict';

  // ----- Column definitions -----------------------------------------------

  const DEFAULT_COLUMNS = [
    { headerText: 'Selection',             field: 'line_id',               template: 'selectionTemplate' },
    { headerText: 'Statement Date',        field: 'stmt_from_date',        template: 'stmtDateTemplate' },
    { headerText: 'Account Name',          field: 'bank_account_name' },
    { headerText: 'Account',               field: 'bank_account_num' },
    { headerText: 'Amount Currency',       field: 'account_currency_code' },
    { headerText: 'Amount',                field: 'entry_amt' },
    { headerText: 'Classification',        field: 'classification',        template: 'classificationTemplate' },
    { headerText: 'JE Group',              field: 'je_grouping',           template: 'jeTemplate' },
    { headerText: 'Distributions',         field: 'distributions',         template: 'Distributions' },
    { headerText: 'JE Reversal Status',    field: 'je_reversal_status',    template: 'JE Reversal Status'},
    { headerText: 'JE Reversal Reason',    field: 'reversal_reason',       template: 'JE Reversal Reason' },
    { headerText: 'Awaiting Distributions',field: 'awaiting_distributions',template: 'AwaitingDistribution' },
    { headerText: 'Transaction Type',      field: 'transaction_type' },
    { headerText: 'Domain Code',           field: 'entry_domain_code' },
    { headerText: 'Family Code',           field: 'entry_family_code' },
    { headerText: 'Sub Family Code',       field: 'entry_subfamily_code' },
    { headerText: 'BAI Code',              field: 'entry_bai_code' },
    { headerText: 'Customer Reference',    field: 'customer_reference' },
    { headerText: 'Description',           field: 'description' },
    { headerText: 'Statement Number',      field: 'statement_number' },
  ];

  const ALL_COLUMNS = [
    // --- Default columns (retained first for familiar order) ---
    ...DEFAULT_COLUMNS,
    // --- Additional columns shown only in "View All" ---

	{ headerText: 'Ledger Name',             			field: 'ledger_name' },
    { headerText: 'Classification Rule ID',      		field: 'rule_def_id' },
    { headerText: 'Classification Rule Name',      		field: 'classify_rule_name' },
    { headerText: 'Classification Rule Version',   		field: 'classify_rule_version' },
	{ headerText: 'Journalization Rule ID',      		field: 'je_rule_id' },
	{ headerText: 'Journalization Rule Name',           field: 'je_rule_name' },
    { headerText: 'Journalization Rule Version',        field: 'je_rule_version' },
	{ headerText: 'Cash GL Account',                    field: 'cash_gl_account' },
	{ headerText: 'Company Code',                       field: 'company_code' },
	{ headerText: 'GL Account',                         field: 'gl_account' },
	{ headerText: 'Bank Transfer',              	    field: 'bank_transfer' },
	{ headerText: 'Offset Account Number',   		    field: 'offset_account_number' },
	{ headerText: 'Offset Ledger',      		    field: 'offset_ledger_name' },
	{ headerText: 'Offset IC Credit',       		    field: 'offset_cr_account' },
    { headerText: 'Offset IC Debit',       			    field: 'offset_dr_account' },
	{ headerText: 'File Name',               		    field: 'file_name' },
	{ headerText: 'Header Message',             	    field: 'hdr_message' },
	{ headerText: 'Line Message',            		    field: 'line_message' },
	{ headerText: 'GL Status',               		    field: 'gl_status' },
	{ headerText: 'Oracle CE Transfer',           	    field: 'sent_to_ce' },
	{ headerText: 'Line Number',             		    field: 'line_number' },
    { headerText: 'Reconciliation Status',              field: 'recon_status' },
    { headerText: 'Reconciliation Reference',           field: 'reconciliation_reference' },
    { headerText: 'Reconciled Amount',                  field: 'recon_amount' },
    { headerText: 'Exchange Currency',                  field: 'exchange_currency' },
    { headerText: 'Exchange Rate Date',                 field: 'exchange_rate_date' },
    { headerText: 'Exchange Rate',                      field: 'exchange_rate' },
    { headerText: 'Exchange Amount',                    field: 'exchange_amount' },
    { headerText: 'Opening Balance',                    field: 'control_begin_balance' },
    { headerText: 'Closing Balance',                    field: 'control_end_balance' },
    { headerText: 'Number of Credit Entries',           field: 'trx_cred_ent_no' },
    { headerText: 'Number of Debit Entries',            field: 'trx_deb_ent_no' },
    { headerText: 'Manual Override',                    field: 'manual_override' },

  ];

  // ------------------------------------------------------------------------

  class ColumnViewChangeActionChain extends ActionChain {
    async run(context, { event, selectedView }) {
      const { $page } = context;

      const columns = selectedView === 'all' ? ALL_COLUMNS : DEFAULT_COLUMNS;

      // oj-table does not reliably tear down the previous column set when
      // the columns array is swapped in one shot - the new set gets appended
      // to the stale one. Clear first, yield a tick so the table processes
      // the empty set, then assign the new columns.
      $page.variables.tableColumnsVar = [];

      await new Promise((resolve) => setTimeout(resolve, 0));

      // Fresh copies so the variable never points at the shared constants
      $page.variables.tableColumnsVar = columns.map((c) => ({ ...c }));
    }
  }

  return ColumnViewChangeActionChain;
});