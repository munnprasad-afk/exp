define([
  'vb/action/actionChain',
], (
  ActionChain
) => {
  'use strict';

  class hdrFetchStatsActionChain extends ActionChain {

    async run(context, { stats }) {
      context.$variables.hdrStatsVar = Object.assign({}, stats);
    }
  }

  return hdrFetchStatsActionChain;
});
