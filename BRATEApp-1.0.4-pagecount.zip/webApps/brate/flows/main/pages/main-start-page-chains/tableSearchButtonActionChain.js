define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class tableSearchButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.hdrlinedataBDP.instance.resetAllUnsubmittedItems();

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.hdrlinedataSDP,
      });
    }
  }

  return tableSearchButtonActionChain;
});
