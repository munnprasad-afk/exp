define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (ActionChain, Actions, ActionUtils) => {
  'use strict';

  // ----- Column definitions -----------------------------------------------

  const DEFAULT_COLUMNS = [
    { headerText: 'Selection',             field: 'line_id',               template: 'selectionTemplate', sortable: 'disabled' },
    { headerText: 'Statement Date',        field: 'stmt_from_date',        template: 'stmtDateTemplate' },
    { headerText: 'Account Name',          field: 'bank_account_name', template: 'wrapTemplate', width: 220 },
    { headerText: 'Account',               field: 'bank_account_num', template: 'wrapTemplate' },
    { headerText: 'Amount Currency',       field: 'account_currency_code', template: 'wrapTemplate' },
    { headerText: 'Amount',                field: 'entry_amt', template: 'amountTemplate', className: 'oj-helper-text-align-end', headerClassName: 'oj-helper-text-align-end' },
    { headerText: 'Classification',        field: 'classification',        template: 'classificationTemplate' },
    { headerText: 'JE Group',              field: 'je_grouping',           template: 'jeTemplate' },
    { headerText: 'Distributions',         field: 'distributions',         template: 'Distributions', sortable: 'disabled' },
    { headerText: 'JE Reversal Status',    field: 'je_reversal_status',    template: 'JE Reversal Status', sortable: 'disabled' },
    { headerText: 'JE Reversal Reason',    field: 'reversal_reason',       template: 'JE Reversal Reason' },
    { headerText: 'Awaiting Distributions',field: 'awaiting_distributions',template: 'AwaitingDistribution', sortable: 'disabled' },
    { headerText: 'Transaction Type',      field: 'transaction_type', template: 'wrapTemplate' },
    { headerText: 'Domain Code',           field: 'entry_domain_code', template: 'wrapTemplate' },
    { headerText: 'Family Code',           field: 'entry_family_code', template: 'wrapTemplate' },
    { headerText: 'Sub Family Code',       field: 'entry_subfamily_code', template: 'wrapTemplate' },
    { headerText: 'BAI Code',              field: 'entry_bai_code', template: 'wrapTemplate' },
    { headerText: 'Customer Reference',    field: 'customer_reference', template: 'wrapTemplate', width: 220 },
    { headerText: 'Description',           field: 'description', template: 'wrapTemplate', width: 350 },
    { headerText: 'Statement Number',      field: 'statement_number', template: 'wrapTemplate' },
  ];

  const ALL_COLUMNS = [
    // --- Default columns (retained first for familiar order) ---
    ...DEFAULT_COLUMNS,
    // --- Additional columns shown only in "View All" ---

	{ headerText: 'Ledger Name',             			field: 'ledger_name', template: 'wrapTemplate' },
    { headerText: 'Classification Rule ID',      		field: 'rule_def_id', template: 'wrapTemplate' },
    { headerText: 'Classification Rule Name',      		field: 'classify_rule_name', template: 'wrapTemplate' },
    { headerText: 'Classification Rule Version',   		field: 'classify_rule_version', template: 'wrapTemplate' },
	{ headerText: 'Journalization Rule ID',      		field: 'je_rule_id', template: 'wrapTemplate' },
	{ headerText: 'Journalization Rule Name',           field: 'je_rule_name', template: 'wrapTemplate' },
    { headerText: 'Journalization Rule Version',        field: 'je_rule_version', template: 'wrapTemplate' },
	{ headerText: 'Cash GL Account',                    field: 'cash_gl_account', template: 'wrapTemplate' },
	{ headerText: 'Company Code',                       field: 'company_code', template: 'wrapTemplate' },
	{ headerText: 'GL Account',                         field: 'gl_account', template: 'wrapTemplate' },
	{ headerText: 'Bank Transfer',              	    field: 'bank_transfer', template: 'wrapTemplate', sortable: 'disabled' },
	{ headerText: 'Offset Account Number',   		    field: 'offset_account_number', template: 'wrapTemplate', sortable: 'disabled' },
	{ headerText: 'Offset Ledger',      		    field: 'offset_ledger_name', template: 'wrapTemplate' },
	{ headerText: 'Offset IC Credit',       		    field: 'offset_cr_account', template: 'wrapTemplate' },
    { headerText: 'Offset IC Debit',       			    field: 'offset_dr_account', template: 'wrapTemplate' },
	{ headerText: 'File Name',               		    field: 'file_name', template: 'wrapTemplate', width: 250 },
	{ headerText: 'Header Message',             	    field: 'hdr_message', template: 'wrapTemplate', width: 300 },
	{ headerText: 'Line Message',            		    field: 'line_message', template: 'wrapTemplate', width: 300 },
	{ headerText: 'GL Status',               		    field: 'gl_status', template: 'wrapTemplate' },
	{ headerText: 'Oracle CE Transfer',           	    field: 'sent_to_ce', template: 'wrapTemplate' },
	{ headerText: 'Line Number',             		    field: 'line_number', template: 'wrapTemplate' },
    { headerText: 'Reconciliation Status',              field: 'recon_status', template: 'wrapTemplate' },
    { headerText: 'Reconciliation Reference',           field: 'reconciliation_reference', template: 'wrapTemplate', sortable: 'disabled' },
    { headerText: 'Reconciled Amount',                  field: 'recon_amount', template: 'amountTemplate', className: 'oj-helper-text-align-end', headerClassName: 'oj-helper-text-align-end' },
    { headerText: 'Exchange Currency',                  field: 'exchange_currency', template: 'wrapTemplate' },
    { headerText: 'Exchange Rate Date',                 field: 'exchange_rate_date', template: 'wrapTemplate' },
    { headerText: 'Exchange Rate',                      field: 'exchange_rate', template: 'wrapTemplate' },
    { headerText: 'Exchange Amount',                    field: 'exchange_amount', template: 'amountTemplate', className: 'oj-helper-text-align-end', headerClassName: 'oj-helper-text-align-end' },
    { headerText: 'Opening Balance',                    field: 'control_begin_balance', template: 'amountTemplate', className: 'oj-helper-text-align-end', headerClassName: 'oj-helper-text-align-end' },
    { headerText: 'Closing Balance',                    field: 'control_end_balance', template: 'amountTemplate', className: 'oj-helper-text-align-end', headerClassName: 'oj-helper-text-align-end' },
    { headerText: 'Number of Credit Entries',           field: 'trx_cred_ent_no', template: 'wrapTemplate' },
    { headerText: 'Number of Debit Entries',            field: 'trx_deb_ent_no', template: 'wrapTemplate' },
    { headerText: 'Manual Override',                    field: 'manual_override', template: 'wrapTemplate' },

  ];

  // ------------------------------------------------------------------------

  class ColumnViewChangeActionChain extends ActionChain {
    async run(context, { event, selectedView }) {
      const { $page } = context;

      const columns = selectedView === 'all' ? ALL_COLUMNS : DEFAULT_COLUMNS;

      // oj-table does not reliably tear down the previous column set when
      // the columns array is swapped in one shot - the new set gets appended
      // to the stale one. Clear first, yield a tick so the table processes
      // the empty set, then assign the new columns.
      $page.variables.tableColumnsVar = [];

      await new Promise((resolve) => setTimeout(resolve, 0));

      // Fresh copies so the variable never points at the shared constants
      $page.variables.tableColumnsVar = columns.map((c) => ({ ...c }));
    }
  }

  return ColumnViewChangeActionChain;
});