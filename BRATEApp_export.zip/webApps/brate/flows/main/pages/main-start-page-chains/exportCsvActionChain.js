define([
  'vb/action/actionChain',
  'vb/action/actions',
], (ActionChain, Actions) => {
  'use strict';

  const DEFAULT_COLUMNS = [
    { field: 'stmt_from_date', headerText: 'Statement Date' },
    { field: 'bank_account_name', headerText: 'Account Name' },
    { field: 'bank_account_num', headerText: 'Account' },
    { field: 'account_currency_code', headerText: 'Amount Currency' },
    { field: 'entry_amt', headerText: 'Amount' },
    { field: 'classification', headerText: 'Classification' },
    { field: 'je_grouping', headerText: 'JE Group' },
    { field: 'distributions', headerText: 'Distributions' },
    { field: 'je_reversal_status', headerText: 'JE Reversal Status' },
    { field: 'reversal_reason', headerText: 'JE Reversal Reason' },
    { field: 'awaiting_distributions', headerText: 'Awaiting Distributions' },
    { field: 'transaction_type', headerText: 'Transaction Type' },
    { field: 'entry_domain_code', headerText: 'Domain Code' },
    { field: 'entry_family_code', headerText: 'Family Code' },
    { field: 'entry_subfamily_code', headerText: 'Sub Family Code' },
    { field: 'entry_bai_code', headerText: 'BAI Code' },
    { field: 'customer_reference', headerText: 'Customer Reference' },
    { field: 'description', headerText: 'Description' },
    { field: 'statement_number', headerText: 'Statement Number' },
  ];

  const ALL_COLUMNS = [
    { field: 'stmt_from_date', headerText: 'Statement Date' },
    { field: 'bank_account_name', headerText: 'Account Name' },
    { field: 'bank_account_num', headerText: 'Account' },
    { field: 'account_currency_code', headerText: 'Amount Currency' },
    { field: 'entry_amt', headerText: 'Amount' },
    { field: 'classification', headerText: 'Classification' },
    { field: 'je_grouping', headerText: 'JE Group' },
    { field: 'distributions', headerText: 'Distributions' },
    { field: 'je_reversal_status', headerText: 'JE Reversal Status' },
    { field: 'reversal_reason', headerText: 'JE Reversal Reason' },
    { field: 'awaiting_distributions', headerText: 'Awaiting Distributions' },
    { field: 'transaction_type', headerText: 'Transaction Type' },
    { field: 'entry_domain_code', headerText: 'Domain Code' },
    { field: 'entry_family_code', headerText: 'Family Code' },
    { field: 'entry_subfamily_code', headerText: 'Sub Family Code' },
    { field: 'entry_bai_code', headerText: 'BAI Code' },
    { field: 'customer_reference', headerText: 'Customer Reference' },
    { field: 'description', headerText: 'Description' },
    { field: 'statement_number', headerText: 'Statement Number' },
    { field: 'ledger_name', headerText: 'Ledger Name' },
    { field: 'rule_def_id', headerText: 'Classification Rule ID' },
    { field: 'classify_rule_name', headerText: 'Classify Rule Name' },
    { field: 'classify_rule_version', headerText: 'Classify Rule Version' },
    { field: 'je_rule_id', headerText: 'Journalization Rule ID' },
    { field: 'je_rule_name', headerText: 'Journalization Rule Name' },
    { field: 'je_rule_version', headerText: 'Journalization Rule Version' },
    { field: 'cash_gl_account', headerText: 'Cash GL Account' },
    { field: 'company_code', headerText: 'Company Code' },
    { field: 'gl_account', headerText: 'GL Account' },
    { field: 'bank_transfer', headerText: 'Bank Transfer' },
    { field: 'offset_account_number', headerText: 'Offset Account Number' },
    { field: 'offset_ledger_name', headerText: 'Offset Ledger Name' },
    { field: 'offset_cr_account', headerText: 'Offset CR Account' },
    { field: 'offset_dr_account', headerText: 'Offset DR Account' },
    { field: 'file_name', headerText: 'File Name' },
    { field: 'hdr_message', headerText: 'Header Message' },
    { field: 'line_message', headerText: 'Line Message' },
    { field: 'gl_status', headerText: 'GL Status' },
    { field: 'sent_to_ce', headerText: 'Sent to CE' },
    { field: 'line_number', headerText: 'Line Number' },
    { field: 'recon_status', headerText: 'Reconciliation Status' },
    { field: 'reconciliation_reference', headerText: 'Reconciliation Reference' },
    { field: 'recon_amount', headerText: 'Reconciled Amount' },
    { field: 'exchange_currency', headerText: 'Exchange Currency' },
    { field: 'exchange_rate_date', headerText: 'Exchange Rate Date' },
    { field: 'exchange_rate', headerText: 'Exchange Rate' },
    { field: 'exchange_amount', headerText: 'Exchange Amount' },
    { field: 'control_begin_balance', headerText: 'Opening Balance' },
    { field: 'control_end_balance', headerText: 'Closing Balance' },
    { field: 'trx_cred_ent_no', headerText: 'Number of Credit Entries' },
    { field: 'trx_deb_ent_no', headerText: 'Number of Debit Entries' },
    { field: 'manual_override', headerText: 'Manual Override' },
  ];

  const PAGE_SIZE = 1000;

  const pad = (n) => String(n).padStart(2, '0');

  const timestamp = () => {
    const d = new Date();
    return d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate())
      + '_' + pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds());
  };

  const csvCell = (v) => {
    if (v === null || v === undefined) {
      return '""';
    }
    return '"' + String(v).replace(/"/g, '""') + '"';
  };

  class exportCsvActionChain extends ActionChain {

    async run(context, { exportType }) {
      const { $variables } = context;

      if ($variables.exportInProgress) {
        return;
      }

      const isAll = exportType === 'all';
      const columns = isAll ? ALL_COLUMNS : DEFAULT_COLUMNS;
      const baseName = isAll ? 'BrateAllExport' : 'BrateDefaultExport';

      const filters = {
        p_bank_account_name_alt: $variables.bankAccountNameVar,
        p_bank_account_num: $variables.bankAccountVar,
        p_bank_name: $variables.bankNameVar,
        p_stmt_date_from: $variables.fromDateVar,
        p_stmt_date_to: $variables.toDateVar,
        p_gl_status: $variables.glStatusVar,
        p_amount: $variables.amountVar,
        p_amount_currency: $variables.amountcurrencyVar,
        p_bai_code: $variables.baicodeVar,
        p_cash_gl_account: $variables.cashglaccountVar,
        p_classification: $variables.classificationVar,
        p_classification_rule_id: $variables.classificationruleidVar,
        p_classification_rule_name: $variables.classificationrulenameVar,
        p_classification_rule_version: $variables.classificationruleversionVar,
        p_closing_balance: $variables.closingbalanceVar,
        p_company_code: $variables.companycodeVar,
        p_customer_reference: $variables.customerreferenceVar,
        p_description: $variables.descriptionVar,
        p_domain_code: $variables.domaincodeVar,
        p_exchange_amount: $variables.exchangeamountVar,
        p_exchange_currency: $variables.exchangecurrencyVar,
        p_exchange_rate: $variables.exchangerateVar,
        p_exchange_rate_date: $variables.exchangeratedateVar,
        p_family_code: $variables.familycodeVar,
        p_file_name: $variables.filenameVar,
        p_gl_account: $variables.glaccountVar,
        p_gl_flag: $variables.glflagVar,
        p_header_message: $variables.headermessageVar,
        p_header_id: $variables.headeridVar,
        p_je_group: $variables.jegroupVar,
        p_je_reversal_reason: $variables.jereversalreasonVar,
        p_je_reversal_status: $variables.jereversalstatusVar,
        p_journalization_rule_id: $variables.journalizationruleidVar,
        p_journalization_rule_name: $variables.journalizationrulenameVar,
        p_journalization_rule_version: $variables.journalizationruleversionVar,
        p_last_update_date: $variables.lastupdatedateVar,
        p_last_updated_by: $variables.lastupdatedbyVar,
        p_ledger_name: $variables.ledgernameVar,
        p_line_message: $variables.linemessageVar,
        p_line_number: $variables.linenumberVar,
        p_line_id: $variables.lineidVar,
        p_manual_override: $variables.manualoverrideVar,
        p_number_of_credit_entries: $variables.numberofcreditentriesVar,
        p_number_of_debit_entries: $variables.numberofdebitentriesVar,
        p_offset_ic_credit: $variables.offseticcreditVar,
        p_offset_ic_debit: $variables.offseticdebitVar,
        p_offset_ledger: $variables.offsetledgerVar,
        p_opening_balance: $variables.openingbalanceVar,
        p_oracle_ce_transfer: $variables.oraclecetransferVar,
        p_reconciled_amount: $variables.reconciledamountVar,
        p_reconciliation_status: $variables.reconciliationstatusVar,
        p_statement_number: $variables.statementnumberVar,
        p_sub_family_code: $variables.subfamilycodeVar,
        p_transaction_type: $variables.transactiontypeVar,
        p_trx_entry_no: $variables.trxentrynoVar,
      };

      const uriParams = {};
      Object.keys(filters).forEach((k) => {
        const v = filters[k];
        if (v !== null && v !== undefined && String(v).trim() !== '') {
          uriParams[k] = v;
        }
      });

      $variables.exportInProgress = true;

      try {
        const rows = [];
        let offset = 0;
        let hasMore = true;

        while (hasMore) {
          const response = await Actions.callRest(context, {
            endpoint: 'hdrlindata/get',
            uriParams: Object.assign({}, uriParams, { limit: PAGE_SIZE, offset: offset }),
          });

          if (!response.ok) {
            await Actions.fireNotificationEvent(context, {
              summary: 'Export Failed',
              message: (response.body && response.body.message) || ('HTTP ' + response.status),
              type: 'error',
              displayMode: 'transient',
            });
            return;
          }

          const items = (response.body && Array.isArray(response.body.items)) ? response.body.items : [];
          rows.push(...items);
          offset += items.length;
          hasMore = !!(response.body && response.body.hasMore) && items.length > 0;
        }

        if (rows.length === 0) {
          await Actions.fireNotificationEvent(context, {
            summary: 'No Data',
            message: 'No records found for the current filters.',
            type: 'warning',
            displayMode: 'transient',
          });
          return;
        }

        const lines = [columns.map((c) => csvCell(c.headerText)).join(',')];
        rows.forEach((r) => {
          lines.push(columns.map((c) => csvCell(r[c.field])).join(','));
        });

        const blob = new Blob(['\uFEFF' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = baseName + '_' + timestamp() + '.csv';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        await Actions.fireNotificationEvent(context, {
          summary: 'Export Complete',
          message: rows.length + ' rows exported.',
          type: 'confirmation',
          displayMode: 'transient',
        });
      } catch (error) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Export Error',
          message: (error && error.message) ? error.message : 'Unexpected error.',
          type: 'error',
          displayMode: 'transient',
        });
      } finally {
        $variables.exportInProgress = false;
      }
    }
  }

  return exportCsvActionChain;
});
