define([], () => {
  'use strict';

  class PageModule {

    constructor(context) {
      this.eventHelper = context.getEventHelper();

      this.hdrRequestPaginate = (configuration, options) => {
        const url = configuration.url;
        configuration.url = url + (url.indexOf('?') >= 0 ? '&' : '?')
          + 'limit=' + encodeURIComponent(options.size) + '&offset=' + encodeURIComponent(options.offset);
        return configuration;
      };

      const sortableFields = [
        'stmt_from_date', 'bank_account_name', 'bank_account_num', 'account_currency_code', 'entry_amt',
        'classification', 'je_grouping', 'reversal_reason', 'transaction_type', 'entry_domain_code',
        'entry_family_code', 'entry_subfamily_code', 'entry_bai_code', 'customer_reference', 'description',
        'statement_number', 'ledger_name', 'rule_def_id', 'classify_rule_name', 'classify_rule_version',
        'je_rule_id', 'je_rule_name', 'je_rule_version', 'cash_gl_account', 'company_code', 'gl_account',
        'offset_ledger_name', 'offset_cr_account', 'offset_dr_account', 'file_name', 'hdr_message',
        'line_message', 'gl_status', 'sent_to_ce', 'line_number', 'recon_status', 'recon_amount',
        'exchange_currency', 'exchange_rate_date', 'exchange_rate', 'exchange_amount',
        'control_begin_balance', 'control_end_balance', 'trx_cred_ent_no', 'trx_deb_ent_no', 'manual_override',
      ];

      this.hdrRequestSort = (configuration, options) => {
        const criterion = Array.isArray(options) && options.length > 0 ? options[0] : null;
        if (!criterion || sortableFields.indexOf(criterion.attribute) < 0) {
          return configuration;
        }
        const url = configuration.url;
        configuration.url = url + (url.indexOf('?') >= 0 ? '&' : '?')
          + 'p_sort_col=' + encodeURIComponent(criterion.attribute)
          + '&p_sort_dir=' + (criterion.direction === 'descending' ? 'desc' : 'asc');
        return configuration;
      };

      this.hdrResponsePaginate = (result) => {
        const tr = {};
        if (result && result.body) {
          tr.data = result.body.items;
          tr.hasMore = !!result.body.hasMore;
        } else {
          tr.hasMore = false;
        }
        return tr;
      };

      this.hdrResponseBody = (result) => {
        const body = result ? result.body : undefined;
        if (!body || !Array.isArray(body.items) || body.offset === undefined) {
          return body;
        }
        const size = Number(body.limit) || 25;
        const offset = Number(body.offset) || 0;
        const count = body.count != null ? Number(body.count) : body.items.length;
        if (count === 0 && offset > 0) {
          return body;
        }
        const total = count > 0 ? Number(body.items[0].total_records) || 0 : 0;
        this.eventHelper.fireCustomEvent('hdrFetchStats', {
          stats: {
            totalRecords: total,
            loadedCount: offset + count,
            page: count > 0 ? Math.floor(offset / size) + 1 : 0,
            totalPages: Math.ceil(total / size),
          },
        });
        return body;
      };
    }

    formatDate(dateStr) {
      if (!dateStr) return '';
      const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(dateStr));
      if (!m) return '';
      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      return `${m[3]}-${monthNames[Number(m[2]) - 1]}-${m[1]}`;
    }
  }

  return PageModule;
});
