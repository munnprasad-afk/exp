define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getFetch7 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{hookHandler:'vb/RestHookHandler'}} params.configuration
     */
    async run(context, { configuration }) {
      const fetchOptions = configuration.hookHandler.context.fetchOptions || {};
      const criterion = fetchOptions.filterCriterion;
      const text = criterion && criterion.text != null ? String(criterion.text).trim() : '';

      if (text) {
        return Actions.callRest(context, {
          endpoint: 'GljeOutputString/get',
          responseType: 'getGLOutputStringSDP',
          hookHandler: configuration.hookHandler,
          requestType: 'json',
          uriParams: {
            q: JSON.stringify({ je_output_string: { $instr: text } }),
          },
        });
      }

      return Actions.callRest(context, {
        endpoint: 'GljeOutputString/get',
        responseType: 'getGLOutputStringSDP',
        hookHandler: configuration.hookHandler,
        requestType: 'json',
      });
    }
  }

  return getFetch7;
});
