define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils'
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PageVbEnterChain extends ActionChain {

    async run(context, { event }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const PAGE_SIZE = 10000;

      const loadAllGljeOutputString = async () => {
        const all = [];
        const seen = new Set();
        let offset = 0;
        let hasMore = true;

        while (hasMore) {
          const response = await Actions.callRest(context, {
            endpoint: 'GljeOutputString/get',
            uriParams: {
              limit: PAGE_SIZE,
              offset: offset,
            },
          });

          if (!response.ok || !response.body || !Array.isArray(response.body.items)) {
            await Actions.fireNotificationEvent(context, {
              summary: 'GL Account Strings Load Failed',
              message: 'Loaded ' + all.length.toLocaleString() + ' rows before error (HTTP ' + response.status + ').',
              type: 'error',
              displayMode: 'transient',
            });
            break;
          }

          const items = response.body.items;
          for (const item of items) {
            if (item.je_output_string != null && !seen.has(item.je_output_string)) {
              seen.add(item.je_output_string);
              all.push(item);
            }
          }

          offset += items.length;
          hasMore = !!response.body.hasMore && items.length > 0;
        }

        $variables.getgljeoutputstringADP.data = all;
      };

      $variables.pageLoadingVar = true;

      try {
        await Promise.all([
          (async () => {
            const response = await Actions.callRest(context, {
              endpoint: 'classification/get',
              uriParams: {
                limit: 10000,
                offset: 0,
              },
            });
            if (response.ok && response.body) {
              $variables.classificationADP.data = response.body.items;
            }
          })(),
          (async () => {
            const response2 = await Actions.callRest(context, {
              endpoint: 'jeGrouping/get',
              uriParams: {
                limit: 10000,
                offset: 0,
              },
            });
            if (response2.ok && response2.body) {
              $variables.jeGroupingADP.data = response2.body.items;
            }
          })(),
          loadAllGljeOutputString(),
        ]);
      } catch (error) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Page Load Error',
          message: (error && error.message) ? error.message : 'Unexpected error.',
          type: 'error',
          displayMode: 'transient',
        });
      } finally {
        $variables.pageLoadingVar = false;
      }

$variables.advancedSearchVar.amountVar = false;                           
$variables.advancedSearchVar.amountcurrencyVar = false;                  
$variables.advancedSearchVar.baicodeVar = false;                         
$variables.advancedSearchVar.cashglaccountVar = false;                  
$variables.advancedSearchVar.classificationVar = false;                   
$variables.advancedSearchVar.classificationruleidVar = false;           
$variables.advancedSearchVar.classificationrulenameVar = false;         
$variables.advancedSearchVar.classificationruleversionVar = false;      
$variables.advancedSearchVar.closingbalanceVar = false;                  
$variables.advancedSearchVar.companycodeVar = false;                     
$variables.advancedSearchVar.customerreferenceVar = false;               
$variables.advancedSearchVar.descriptionVar = false;                      
$variables.advancedSearchVar.domaincodeVar = false;                      
$variables.advancedSearchVar.exchangeamountVar = false;                  
$variables.advancedSearchVar.exchangecurrencyVar = false;                
$variables.advancedSearchVar.exchangerateVar = false;                    
$variables.advancedSearchVar.exchangeratedateVar = false;               
$variables.advancedSearchVar.familycodeVar = false;                      
$variables.advancedSearchVar.filenameVar = false;                        
$variables.advancedSearchVar.glaccountVar = false;                       
$variables.advancedSearchVar.glflagVar = false;                          
$variables.advancedSearchVar.headermessageVar = false;                   
$variables.advancedSearchVar.headeridVar = false;                        
$variables.advancedSearchVar.jegroupVar = false;                         
$variables.advancedSearchVar.jereversalreasonVar = false;               
$variables.advancedSearchVar.jereversalstatusVar = false;               
$variables.advancedSearchVar.journalizationruleidVar = false;           
$variables.advancedSearchVar.journalizationrulenameVar = false;         
$variables.advancedSearchVar.journalizationruleversionVar = false;      
$variables.advancedSearchVar.lastupdatedateVar = false;                 
$variables.advancedSearchVar.lastupdatedbyVar = false;                  
$variables.advancedSearchVar.ledgernameVar = false;                      
$variables.advancedSearchVar.linemessageVar = false;                     
$variables.advancedSearchVar.linenumberVar = false;                      
$variables.advancedSearchVar.lineidVar = false;                          
$variables.advancedSearchVar.manualoverrideVar = false;                  
$variables.advancedSearchVar.numberofcreditentriesVar = false;         
$variables.advancedSearchVar.numberofdebitentriesVar = false;          
$variables.advancedSearchVar.offseticcreditVar = false;                 
$variables.advancedSearchVar.offseticdebitVar = false;                  
$variables.advancedSearchVar.offsetledgerVar = false;                    
$variables.advancedSearchVar.openingbalanceVar = false;                  
$variables.advancedSearchVar.oraclecetransferVar = false;               
$variables.advancedSearchVar.reconciledamountVar = false;                
$variables.advancedSearchVar.reconciliationstatusVar = false;            
$variables.advancedSearchVar.statementnumberVar = false;                 
$variables.advancedSearchVar.subfamilycodeVar = false;                  
$variables.advancedSearchVar.transactiontypeVar = false;                 
$variables.advancedSearchVar.trxentrynoVar = false;                     
    }
  }

  return PageVbEnterChain;
});
