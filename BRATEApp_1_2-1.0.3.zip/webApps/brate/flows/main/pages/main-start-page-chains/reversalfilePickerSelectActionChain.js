define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (ActionChain, Actions, ActionUtils) => {
  'use strict';

  class reversalfilePickerSelectActionChain extends ActionChain {

    async run(context, { event, originalEvent }) {
      const { $page, $variables } = context;

      const files = event.detail.files;
      if (!files || files.length === 0) {
        return;
      }

      await ActionUtils.forEach(Array.from(files), async (file) => {

        // Convert file to base64
        const base64 = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => {
            // result is "data:<mime>;base64,<data>" - strip the prefix
            const base64String = reader.result.split(',')[1];
            resolve(base64String);
          };
          reader.onerror = () => reject(new Error('Failed to read file: ' + file.name));
          reader.readAsDataURL(file);
        });

        const body = {
          line_id: Number($variables.lineIdVar),
          created_by: $variables.createdByUser,
          file_name: file.name,
          document: base64,
        };

        try {
          const response = await Actions.callRest(context, {
            endpoint: 'addReversalDocuments/post',
            body: body,
          });


          if (!response.ok) {
            await Actions.fireNotificationEvent(context, {
              summary: 'Upload Failed: ' + file.name,
              message: response.body && response.body.message ? response.body.message : 'Upload error.',
              type: 'error',
              displayMode: 'transient',
            });
            return;
          }

          await Actions.fireNotificationEvent(context, {
            summary: 'File Uploaded: ' + file.name,
            message: 'Document saved successfully.',
            type: 'confirmation',
            displayMode: 'transient',
          });

          // Refresh the documents table
          await Actions.fireDataProviderEvent(context, {
            refresh: null,
            target: $variables.listDocumentsSDP,
          });

        } catch (error) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Upload Error: ' + file.name,
            message: (error && error.message) ? error.message : 'Unexpected error.',
            type: 'error',
            displayMode: 'transient',
          });
        }

      }, { mode: 'serial' });
    }
  }

  return reversalfilePickerSelectActionChain;
});
