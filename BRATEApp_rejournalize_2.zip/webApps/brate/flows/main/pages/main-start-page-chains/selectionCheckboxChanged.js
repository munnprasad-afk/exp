define([
  'vb/action/actionChain',
  'vb/action/actions',
], (ActionChain, Actions) => {
  'use strict';

  class selectionCheckboxChanged extends ActionChain {

    async run(context, { event, rowData }) {
      const { $variables } = context;

      const newVal = (event && event.detail && event.detail.value) || [];
      const oldVal = (event && event.detail && event.detail.previousValue) || [];

      const current = Array.isArray($variables.selectedLineIds)
        ? $variables.selectedLineIds.slice()
        : [];

      const lineId = rowData && rowData.line_id;

      if (newVal.length > oldVal.length) {

        // checked - only store the row if it has a line id
        if (lineId !== null && lineId !== undefined) {
          const exists = current.some((l) => l.lineId === lineId);
          if (!exists) {
            current.push({
              lineId: lineId,
              jeGrouping: rowData.je_grouping,
              bank: rowData.bank_account_num,
            });
          }
        }

      } else {

        // unchecked - remove the matching entry
        const idx = current.findIndex((l) => l.lineId === lineId);
        if (idx > -1) {
          current.splice(idx, 1);
        }
      }

      $variables.selectedLineIds = current;

      console.log('selectedLineIds:', JSON.stringify(current));
    }
  }

  return selectionCheckboxChanged;
});
