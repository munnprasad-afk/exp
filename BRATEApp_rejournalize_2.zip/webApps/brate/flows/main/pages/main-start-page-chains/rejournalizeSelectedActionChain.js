define([
  'vb/action/actionChain',
  'vb/action/actions',
], (ActionChain, Actions) => {
  'use strict';

  class rejournalizeSelectedActionChain extends ActionChain {

    async run(context, { event, originalEvent }) {
      const { $variables } = context;

      const selected = Array.isArray($variables.selectedLineIds)
        ? $variables.selectedLineIds
        : [];

      if (selected.length === 0) {
        await Actions.fireNotificationEvent(context, {
          summary: 'No Lines Selected',
          message: 'Select at least one line before re-journalizing.',
          type: 'warning',
          displayMode: 'transient',
        });
        return;
      }

      const isBlankOrNone = (val) => {
        if (val === null || val === undefined) {
          return true;
        }
        const trimmed = String(val).trim();
        return trimmed === '' || trimmed === 'None';
      };

      const lines = selected
        .filter((l) => l.lineId !== null && l.lineId !== undefined && !isBlankOrNone(l.jeGrouping))
        .map((l) => ({
          lineId: l.lineId,
          jeGrouping: l.jeGrouping,
          bankAccountNumber: l.bank,
        }));

      if (lines.length === 0) {
        await Actions.fireNotificationEvent(context, {
          summary: 'No Valid Lines',
          message: 'None of the selected lines have a Line Id and a valid JE Grouping.',
          type: 'warning',
          displayMode: 'transient',
        });
        return;
      }

      const body = {
        userId: '0',
        lines: lines,
      };

      console.log('rejournalize body:', JSON.stringify(body));

      try {
        const response = await Actions.callRest(context, {
          endpoint: 'rejournalize/postIcApiIntegrationV1FlowsRestTRANSACTIONUIREJOURNALIZE1_0BrateprocessRejournalize',
          body: body,
        });

        if (!response.ok) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Re-Journalize Failed',
            message: (response.body && response.body.status) ? response.body.status : 'Request failed.',
            type: 'error',
            displayMode: 'transient',
          });
          return;
        }

        const resBody = response.body || {};

        await Actions.fireNotificationEvent(context, {
          summary: 'Re-Journalize Submitted',
          message: 'Processed: ' + (resBody.processedCount || 0)
            + ' | Skipped: ' + (resBody.skippedCount || 0)
            + ' | Errors: ' + (resBody.errorCount || 0),
          type: 'confirmation',
          displayMode: 'transient',
        });

        $variables.selectedLineIds = [];

        await Actions.fireDataProviderEvent(context, {
          refresh: null,
          target: $variables.hdrlinedataSDP,
        });

      } catch (error) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Re-Journalize Error',
          message: (error && error.message) ? error.message : 'Unexpected error.',
          type: 'error',
          displayMode: 'transient',
        });
      }
    }
  }

  return rejournalizeSelectedActionChain;
});
