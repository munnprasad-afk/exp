define([
  'vb/action/actionChain',
  'vb/action/actions',
], (ActionChain, Actions) => {
  'use strict';

  class selectionCheckboxChanged extends ActionChain {

    async run(context, { event }) {
      const { $variables } = context;

      const newVal = (event && event.detail && event.detail.value) || [];
      const oldVal = (event && event.detail && event.detail.previousValue) || [];

      const current = Array.isArray($variables.selectedLineIds)
        ? $variables.selectedLineIds.slice()
        : [];

      if (newVal.length > oldVal.length) {
        const id = newVal[0];
        if (id !== undefined && id !== null && !current.includes(id)) {
          current.push(id);
        }
      } else {
        const id = oldVal[0];
        const idx = current.indexOf(id);
        if (idx > -1) {
          current.splice(idx, 1);
        }
      }

      $variables.selectedLineIds = current;

      console.log('selectedLineIds:', $variables.selectedLineIds);
    }
  }

  return selectionCheckboxChanged;
});
