define([], () => {
  'use strict';

  const COLUMN_CATALOG = [
    { headerText: 'Selection', field: 'line_id', template: 'selectionTemplate', sortable: 'disabled' },
    { headerText: 'Statement Date', field: 'stmt_from_date', template: 'stmtDateTemplate' },
    { headerText: 'Account Name', field: 'bank_account_name' },
    { headerText: 'Account', field: 'bank_account_num' },
    { headerText: 'Amount Currency', field: 'account_currency_code' },
    { headerText: 'Amount', field: 'entry_amt', template: 'amountTemplate', className: 'oj-helper-text-align-end', headerClassName: 'oj-helper-text-align-end' },
    { headerText: 'Classification', field: 'classification', template: 'classificationTemplate' },
    { headerText: 'JE Group', field: 'je_grouping', template: 'jeTemplate' },
    { headerText: 'Distributions', field: 'distributions', template: 'Distributions', sortable: 'disabled' },
    { headerText: 'JE Reversal Status', field: 'je_reversal_status', template: 'JE Reversal Status', sortable: 'disabled' },
    { headerText: 'JE Reversal Reason', field: 'reversal_reason', template: 'JE Reversal Reason' },
    { headerText: 'Awaiting Distributions', field: 'awaiting_distributions', template: 'AwaitingDistribution', sortable: 'disabled' },
    { headerText: 'Transaction Type', field: 'transaction_type' },
    { headerText: 'Domain Code', field: 'entry_domain_code' },
    { headerText: 'Family Code', field: 'entry_family_code' },
    { headerText: 'Sub Family Code', field: 'entry_subfamily_code' },
    { headerText: 'BAI Code', field: 'entry_bai_code' },
    { headerText: 'Customer Reference', field: 'customer_reference' },
    { headerText: 'Description', field: 'description', template: 'descWrapTemplate', width: 350, sortable: 'disabled' },
    { headerText: 'Statement Number', field: 'statement_number' },
    { headerText: 'Ledger Name', field: 'ledger_name', sortable: 'disabled' },
    { headerText: 'Classification Rule ID', field: 'rule_def_id', sortable: 'disabled' },
    { headerText: 'Classification Rule Name', field: 'classify_rule_name', sortable: 'disabled' },
    { headerText: 'Classification Rule Version', field: 'classify_rule_version', sortable: 'disabled' },
    { headerText: 'Journalization Rule ID', field: 'je_rule_id', sortable: 'disabled' },
    { headerText: 'Journalization Rule Name', field: 'je_rule_name', sortable: 'disabled' },
    { headerText: 'Journalization Rule Version', field: 'je_rule_version', sortable: 'disabled' },
    { headerText: 'Cash GL Account', field: 'cash_gl_account', sortable: 'disabled' },
    { headerText: 'Company Code', field: 'company_code', sortable: 'disabled' },
    { headerText: 'GL Account', field: 'gl_account', sortable: 'disabled' },
    { headerText: 'Bank Transfer', field: 'bank_transfer', sortable: 'disabled' },
    { headerText: 'Offset Account Number', field: 'offset_account_number', sortable: 'disabled' },
    { headerText: 'Offset Ledger', field: 'offset_ledger_name', sortable: 'disabled' },
    { headerText: 'Offset IC Credit', field: 'offset_cr_account', sortable: 'disabled' },
    { headerText: 'Offset IC Debit', field: 'offset_dr_account', sortable: 'disabled' },
    { headerText: 'File Name', field: 'file_name', sortable: 'disabled' },
    { headerText: 'Header Message', field: 'hdr_message', sortable: 'disabled' },
    { headerText: 'Line Message', field: 'line_message', sortable: 'disabled' },
    { headerText: 'GL Status', field: 'gl_status', sortable: 'disabled' },
    { headerText: 'Oracle CE Transfer', field: 'sent_to_ce', sortable: 'disabled' },
    { headerText: 'Line Number', field: 'line_number', sortable: 'disabled' },
    { headerText: 'Reconciliation Status', field: 'recon_status', sortable: 'disabled' },
    { headerText: 'Reconciliation Reference', field: 'reconciliation_reference', sortable: 'disabled' },
    { headerText: 'Reconciled Amount', field: 'recon_amount', template: 'amountTemplate', className: 'oj-helper-text-align-end', headerClassName: 'oj-helper-text-align-end', sortable: 'disabled' },
    { headerText: 'Exchange Currency', field: 'exchange_currency', sortable: 'disabled' },
    { headerText: 'Exchange Rate Date', field: 'exchange_rate_date', sortable: 'disabled' },
    { headerText: 'Exchange Rate', field: 'exchange_rate', sortable: 'disabled' },
    { headerText: 'Exchange Amount', field: 'exchange_amount', template: 'amountTemplate', className: 'oj-helper-text-align-end', headerClassName: 'oj-helper-text-align-end', sortable: 'disabled' },
    { headerText: 'Opening Balance', field: 'control_begin_balance', template: 'amountTemplate', className: 'oj-helper-text-align-end', headerClassName: 'oj-helper-text-align-end', sortable: 'disabled' },
    { headerText: 'Closing Balance', field: 'control_end_balance', template: 'amountTemplate', className: 'oj-helper-text-align-end', headerClassName: 'oj-helper-text-align-end', sortable: 'disabled' },
    { headerText: 'Number of Credit Entries', field: 'trx_cred_ent_no', sortable: 'disabled' },
    { headerText: 'Number of Debit Entries', field: 'trx_deb_ent_no', sortable: 'disabled' },
    { headerText: 'Manual Override', field: 'manual_override', sortable: 'disabled' },
  ];

  const LOCKED_FIELD = 'line_id';

  const DEFAULT_FIELDS = [
    'stmt_from_date',
    'bank_account_name',
    'bank_account_num',
    'account_currency_code',
    'entry_amt',
    'classification',
    'je_grouping',
    'distributions',
    'je_reversal_status',
    'reversal_reason',
    'awaiting_distributions',
    'transaction_type',
    'entry_domain_code',
    'entry_family_code',
    'entry_subfamily_code',
    'entry_bai_code',
    'customer_reference',
    'description',
    'statement_number',
  ];

  const CATALOG_BY_FIELD = new Map(COLUMN_CATALOG.map((c) => [c.field, c]));

  const CATALOG_OPTIONS = COLUMN_CATALOG
    .filter((c) => c.field !== LOCKED_FIELD)
    .map((c) => ({ field: c.field, headerText: c.headerText }));

  const ALL_FIELDS = CATALOG_OPTIONS.map((c) => c.field);

  class PageModule {

    constructor(context) {
      this.eventHelper = context.getEventHelper();

      this.hdrRequestPaginate = (configuration, options) => {
        const url = configuration.url;
        configuration.url = url + (url.indexOf('?') >= 0 ? '&' : '?')
          + 'limit=' + encodeURIComponent(options.size) + '&offset=' + encodeURIComponent(options.offset);
        return configuration;
      };

      const sortableFields = [
        'stmt_from_date', 'bank_account_name', 'bank_account_num', 'account_currency_code', 'entry_amt',
        'classification', 'je_grouping', 'reversal_reason', 'transaction_type', 'entry_domain_code',
        'entry_family_code', 'entry_subfamily_code', 'entry_bai_code', 'customer_reference', 'description',
        'statement_number', 'ledger_name', 'rule_def_id', 'classify_rule_name', 'classify_rule_version',
        'je_rule_id', 'je_rule_name', 'je_rule_version', 'cash_gl_account', 'company_code', 'gl_account',
        'offset_ledger_name', 'offset_cr_account', 'offset_dr_account', 'file_name', 'hdr_message',
        'line_message', 'gl_status', 'sent_to_ce', 'line_number', 'recon_status', 'recon_amount',
        'exchange_currency', 'exchange_rate_date', 'exchange_rate', 'exchange_amount',
        'control_begin_balance', 'control_end_balance', 'trx_cred_ent_no', 'trx_deb_ent_no', 'manual_override',
      ];

      this.hdrRequestSort = (configuration, options) => {
        const criterion = Array.isArray(options) && options.length > 0 ? options[0] : null;
        if (!criterion || sortableFields.indexOf(criterion.attribute) < 0) {
          return configuration;
        }
        const url = configuration.url;
        configuration.url = url + (url.indexOf('?') >= 0 ? '&' : '?')
          + 'p_sort_col=' + encodeURIComponent(criterion.attribute)
          + '&p_sort_dir=' + (criterion.direction === 'descending' ? 'desc' : 'asc');
        return configuration;
      };

      this.hdrResponsePaginate = (result) => {
        const tr = {};
        if (result && result.body) {
          tr.data = result.body.items;
          tr.hasMore = !!result.body.hasMore;
        } else {
          tr.hasMore = false;
        }
        return tr;
      };

      this.hdrResponseBody = (result) => {
        const body = result ? result.body : undefined;
        if (!body || !Array.isArray(body.items) || body.offset === undefined) {
          return body;
        }
        const size = Number(body.limit) || 25;
        const offset = Number(body.offset) || 0;
        const count = body.count != null ? Number(body.count) : body.items.length;
        if (count === 0 && offset > 0) {
          return body;
        }
        const total = count > 0 ? Number(body.items[0].total_records) || 0 : 0;
        this.eventHelper.fireCustomEvent('hdrFetchStats', {
          stats: {
            totalRecords: total,
            loadedCount: offset + count,
            page: count > 0 ? Math.floor(offset / size) + 1 : 0,
            totalPages: Math.ceil(total / size),
          },
        });
        return body;
      };
    }

    columnCatalog() {
      return CATALOG_OPTIONS;
    }

    defaultFields() {
      return DEFAULT_FIELDS.slice();
    }

    allFields() {
      return ALL_FIELDS.slice();
    }

    buildColumns(fields) {
      const list = Array.isArray(fields) ? fields : [];
      const seen = new Set();
      const columns = [{ ...CATALOG_BY_FIELD.get(LOCKED_FIELD) }];
      list.forEach((f) => {
        if (f !== LOCKED_FIELD && CATALOG_BY_FIELD.has(f) && !seen.has(f)) {
          seen.add(f);
          columns.push({ ...CATALOG_BY_FIELD.get(f) });
        }
      });
      return columns;
    }

    mergeFieldOrder(currentOrder, checkedFields) {
      const checked = new Set(checkedFields);
      const kept = currentOrder.filter((f) => checked.has(f));
      const keptSet = new Set(kept);
      const added = ALL_FIELDS.filter((f) => checked.has(f) && !keptSet.has(f));
      return kept.concat(added);
    }

    fieldsFromColumns(columns) {
      return (Array.isArray(columns) ? columns : [])
        .map((c) => c.field)
        .filter((f) => f !== LOCKED_FIELD && CATALOG_BY_FIELD.has(f));
    }

    formatDate(dateStr) {
      if (!dateStr) return '';
      const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(dateStr));
      if (!m) return '';
      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      return `${m[3]}-${monthNames[Number(m[2]) - 1]}-${m[1]}`;
    }
  }

  return PageModule;
});
