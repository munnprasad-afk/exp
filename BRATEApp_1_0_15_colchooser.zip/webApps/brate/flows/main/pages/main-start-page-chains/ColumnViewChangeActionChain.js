define([
  'vb/action/actionChain',
  'vb/action/actions',
], (ActionChain, Actions) => {
  'use strict';

  class ColumnViewChangeActionChain extends ActionChain {
    async run(context, { selectedView }) {
      const { $functions } = context;

      const fields = selectedView === 'all' ? $functions.allFields() : $functions.defaultFields();

      await Actions.callChain(context, {
        chain: 'ColumnApplyActionChain',
        params: { fields },
      });
    }
  }

  return ColumnViewChangeActionChain;
});
