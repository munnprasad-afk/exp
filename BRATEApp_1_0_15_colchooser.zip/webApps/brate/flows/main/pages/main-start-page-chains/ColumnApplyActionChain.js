define([
  'vb/action/actionChain',
], (ActionChain) => {
  'use strict';

  class ColumnApplyActionChain extends ActionChain {
    async run(context, { fields }) {
      const { $page, $functions } = context;

      $page.variables.selectedFieldsVar = fields.slice();
      $page.variables.tableColumnsVar = [];

      await new Promise((resolve) => setTimeout(resolve, 0));

      $page.variables.tableColumnsVar = $functions.buildColumns(fields);
    }
  }

  return ColumnApplyActionChain;
});
