define([
  'vb/action/actionChain',
], (ActionChain) => {
  'use strict';

  class ColumnReorderedActionChain extends ActionChain {
    async run(context, { updatedFrom, value }) {
      const { $page, $functions } = context;

      if (updatedFrom !== 'internal') {
        return;
      }

      const fields = $functions.fieldsFromColumns(value);
      const current = $page.variables.selectedFieldsVar;

      if (fields.length !== current.length || fields.every((f, i) => f === current[i])) {
        return;
      }

      $page.variables.selectedFieldsVar = fields;
    }
  }

  return ColumnReorderedActionChain;
});
