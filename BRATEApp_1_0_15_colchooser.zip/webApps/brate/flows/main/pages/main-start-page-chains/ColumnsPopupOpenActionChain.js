define([
  'vb/action/actionChain',
  'vb/action/actions',
], (ActionChain, Actions) => {
  'use strict';

  class ColumnsPopupOpenActionChain extends ActionChain {
    async run(context) {
      await Actions.callComponentMethod(context, {
        selector: '#columnsPopup',
        method: 'open',
        params: ['#columnsButton'],
      });
    }
  }

  return ColumnsPopupOpenActionChain;
});
