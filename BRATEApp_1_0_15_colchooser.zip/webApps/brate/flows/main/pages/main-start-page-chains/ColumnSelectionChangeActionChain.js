define([
  'vb/action/actionChain',
  'vb/action/actions',
], (ActionChain, Actions) => {
  'use strict';

  class ColumnSelectionChangeActionChain extends ActionChain {
    async run(context, { updatedFrom, value }) {
      const { $page, $functions } = context;

      if (updatedFrom !== 'internal' || !Array.isArray(value)) {
        return;
      }

      const current = $page.variables.selectedFieldsVar;
      const fields = $functions.mergeFieldOrder(current, value);

      if (fields.length === current.length && fields.every((f, i) => f === current[i])) {
        return;
      }

      await Actions.callChain(context, {
        chain: 'ColumnApplyActionChain',
        params: { fields },
      });
    }
  }

  return ColumnSelectionChangeActionChain;
});
