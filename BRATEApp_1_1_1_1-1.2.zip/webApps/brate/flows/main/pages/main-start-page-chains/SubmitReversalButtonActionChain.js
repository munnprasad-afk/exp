define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SubmitReversalButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      
        const addJeRevAuditbody = {
  line_id: $variables.lineIdVar,
  reversal_reason: $variables.reversalReasonVar,
  status: "REVERSAL_REQUESTED",
  created_by: "2"
        };


      
      
      
      const response = await Actions.callRest(context, {
        endpoint: 'addJeRevAudit/get',
        body: addJeRevAuditbody,
      });

      const response2 = await Actions.callRest(context, {
        endpoint: 'reversal/postIcApiIntegrationV1FlowsRestTRANSACTIONUIJEREVERSAL1_0Reversal',
        body: addJeRevAuditbody,
      });

      const reverseJournalDialogClose = await Actions.callComponentMethod(context, {
        selector: '#reverseJournalDialog',
        method: 'close',
      });

      await Actions.fireNotificationEvent(context, {
        type: 'info',
        summary: 'Journal Entry Reversal is requested successfully',
      });

      const reverseJournaSubmittedlDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#reverseJournaSubmittedlDialog',
        method: 'open',
      });
    }
  }

  return SubmitReversalButtonActionChain;
});
