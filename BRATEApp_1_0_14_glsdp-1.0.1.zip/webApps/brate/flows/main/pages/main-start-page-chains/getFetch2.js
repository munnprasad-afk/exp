define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class getFetch2 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {{hookHandler:'vb/RestHookHandler'}} params.configuration
     */
    async run(context, { configuration }) {
      const { $page, $flow, $application, $constants, $variables } = context;
	  
	  	  	  if (configuration.hookHandler.context.fetchOptions.filterCriterion) {
				          const callRestEndpoint1 = await Actions.callRest(context, {
          endpoint: ':bnkAccountNumber/get',
		  responseType: 'getvarbankAccountNumberSDP',
		  hookHandler: configuration.hookHandler,
		   requestType: 'json',
          uriParams: {
            q: "{\"bank_account_num\": {\"$instr\": \""  +
            configuration.hookHandler.context.fetchOptions.filterCriterion.text +                         
            "\"}}"
          },
        });
        return callRestEndpoint1; 
			  }
	  
	  
   else{
      const callRestEndpoint1 = await Actions.callRest(context, {
        endpoint: 'bnkAccountNumber/get',
        responseType: 'getvarbankAccountNumberSDP',
        hookHandler: configuration.hookHandler,
        requestType: 'json',
      });

      return callRestEndpoint1;
     }
	  


    }
  }

  return getFetch2;
});
