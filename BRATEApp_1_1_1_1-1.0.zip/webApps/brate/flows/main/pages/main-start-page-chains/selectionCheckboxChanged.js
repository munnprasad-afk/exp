define([
  'vb/action/actionChain',
  'vb/action/actions',
], (ActionChain, Actions) => {
  'use strict';

  class selectionCheckboxChanged extends ActionChain {

    async run(context, { event, row }) {
      const { $variables } = context;

      const checked = event.detail.value && event.detail.value.length > 0;

      const current = Array.isArray($variables.selectedLines)
        ? $variables.selectedLines.slice()
        : [];

      const lineId = row ? row.line_id : undefined;

      if (lineId === null || lineId === undefined) {
        await Actions.fireNotificationEvent(context, {
          message: 'Line Id Not Available for Selected Line',
          summary: 'Line Id Not Available',
          displayMode: 'transient',
          type: 'warning',
        });

        return;
      }

      if (checked) {
        const exists = current.some((l) => l.line_id === lineId);
        if (!exists) {
          current.push({
            line_id: lineId,
            je_grouping: row.je_grouping,
            bank_account_num: row.bank_account_num,
          });
        }
      } else {
        const idx = current.findIndex((l) => l.line_id === lineId);
        if (idx > -1) {
          current.splice(idx, 1);
        }
      }

      $variables.selectedLines = current;

      console.log('selectedLines:', JSON.stringify(current));
    }
  }

  return selectionCheckboxChanged;
});
