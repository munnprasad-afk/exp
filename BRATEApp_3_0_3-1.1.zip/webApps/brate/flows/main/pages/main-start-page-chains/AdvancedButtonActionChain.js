define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class AdvancedButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      const nextVisible = !$variables.advancedLovVisibleVar;

      $variables.advancedLovVisibleVar = nextVisible;

      if (!nextVisible) {
        $variables.advancedFieldVar = '';
      }
    }
  }

  return AdvancedButtonActionChain;
});
