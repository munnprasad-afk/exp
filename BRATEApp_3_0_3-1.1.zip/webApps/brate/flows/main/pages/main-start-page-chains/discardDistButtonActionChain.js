define([
  'vb/action/actionChain',
  'vb/action/actions',
], (ActionChain, Actions) => {
  'use strict';

  class discardDistButtonActionChain extends ActionChain {

    async run(context, { event, originalEvent }) {
      const { $variables } = context;

      $variables.discardDistributionInProgress = true;

      try {

        await Actions.callRest(context, {
          endpoint: 'discardDistribution/get',
          queryParams: {
            'line_id': $variables.lineIdVar,
          },
        });

        $variables.hasAwaitingDistVar = false;

        $variables.distributionRows = [];

        // await Actions.fireDataProviderEvent(context, {
        //   refresh: null,
        //   target: $variables.addDistributionADP,
        // });

        await Actions.callComponentMethod(context, {
          selector: '#addDistributionsDialog',
          method: 'close',
        });

        await Actions.fireNotificationEvent(context, {
          summary: 'Distribution Discarded',
          message: 'The distribution has been discarded.',
          type: 'confirmation',
          displayMode: 'transient'
        });

      } catch (error) {

        await Actions.fireNotificationEvent(context, {
          summary: 'Discard Error',
          message: error.message || JSON.stringify(error),
          type: 'error',
          displayMode: 'transient'
        });

      } finally {
        $variables.discardDistributionInProgress = false;
      }
    }
  }

  return discardDistButtonActionChain;
});