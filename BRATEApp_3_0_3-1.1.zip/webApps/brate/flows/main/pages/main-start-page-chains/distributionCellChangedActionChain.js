define([
  'vb/action/actionChain',
  'vb/action/actions',
], (ActionChain, Actions) => {
  'use strict';

  class distributionCellChangedActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.rowKey
     * @param {string} params.field
     * @param {any} params.value
     */
    async run(context, { rowKey, field, value }) {
      const { $variables } = context;

      if (!rowKey || !field) {
        return;
      }

      const rows = Array.isArray($variables.distributionRows)
        ? $variables.distributionRows
        : [];

      const index = rows.findIndex((row) => row && row.rowKey === rowKey);

      if (index < 0) {
        return;
      }

      rows[index][field] = value;
      if (field === 'amount') { await Actions.callChain(context, { chain: 'refreshAmountActionChain', }); }
    }
  }

  return distributionCellChangedActionChain;
});
