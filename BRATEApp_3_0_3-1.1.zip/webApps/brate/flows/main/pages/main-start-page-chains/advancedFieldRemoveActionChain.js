define([
  'vb/action/actionChain',
  'vb/action/actions',
], (ActionChain, Actions) => {
  'use strict';

  class advancedFieldRemoveActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     */
    async run(context, { event }) {
      const { $variables } = context;

      const origin = (event && (event.target || event.currentTarget)) || null;
      const host = (origin && typeof origin.closest === 'function')
        ? origin.closest('[data-field]')
        : null;
      const field = host ? host.getAttribute('data-field') : null;

      if (!field) {
        return;
      }

      const current = $variables.advancedSearchVar || {};

      if (!Object.prototype.hasOwnProperty.call(current, field)) {
        return;
      }

      const next = Object.assign({}, current);
      next[field] = false;
      $variables.advancedSearchVar = next;

      await Actions.resetVariables(context, {
        variables: ['$variables.' + field],
      });
    }
  }

  return advancedFieldRemoveActionChain;
});
