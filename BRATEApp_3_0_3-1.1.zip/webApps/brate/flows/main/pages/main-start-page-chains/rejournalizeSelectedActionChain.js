define([
  'vb/action/actionChain',
  'vb/action/actions',
], (ActionChain, Actions) => {
  'use strict';

  class rejournalizeSelectedActionChain extends ActionChain {

    async run(context, { event, originalEvent }) {
      const { $variables } = context;

      const selected = Array.isArray($variables.selectedLines)
        ? $variables.selectedLines.filter((l) => l.line_id !== null && l.line_id !== undefined)
        : [];

      if (selected.length === 0) {
        await Actions.fireNotificationEvent(context, {
          summary: 'No Valid Lines Selected',
          message: 'Select at least one line with a valid Line Id before re-journalizing.',
          type: 'warning',
          displayMode: 'transient',
        });
        return;
      }

      const lines = selected.map((l) => ({
        lineId: l.line_id,
        jeGrouping: l.je_grouping,
        bankAccountNumber: l.bank_account_num,
      }));

      const body = {
        userId: '2',
        lines: lines,
      };

      $variables.rejournalizeInProgress = true;

      try {
        const response = await Actions.callRest(context, {
          endpoint: 'rejournalize/postIcApiIntegrationV1FlowsRestTRANSACTIONUIREJOURNALIZE1_0BrateprocessRejournalize',
          body: body,
        });

        if (!response.ok) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Re-Journalize Failed',
            message: (response.body && response.body.status) ? response.body.status : 'Request failed.',
            type: 'error',
            displayMode: 'transient',
          });
               $variables.selectedLines = [];
          return;
        }

        const resBody = response.body || {};

        await Actions.fireNotificationEvent(context, {
          summary: 'Re-Journalize Submitted',
          message: 'Processed: ' + (resBody.processedCount || 0)
            + ' | Skipped: ' + (resBody.skippedCount || 0)
            + ' | Errors: ' + (resBody.errorCount || 0),
          type: 'confirmation',
          displayMode: 'transient',
        });

        $variables.selectedLines = [];

      } catch (error) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Re-Journalize Error',
          message: (error && error.message) ? error.message : 'Unexpected error.',
          type: 'error',
          displayMode: 'transient',
        });
        $variables.selectedLines = [];
      } finally {

         // Wait for exactly 2 seconds (2000 milliseconds)
  await new Promise(resolve => setTimeout(resolve, 5000));

        await Actions.fireDataProviderEvent(context, {
          refresh: null,
          target: $variables.hdrlinedataSDP,
        });
        $variables.rejournalizeInProgress = false;
      }
    }
  }

  return rejournalizeSelectedActionChain;
});
