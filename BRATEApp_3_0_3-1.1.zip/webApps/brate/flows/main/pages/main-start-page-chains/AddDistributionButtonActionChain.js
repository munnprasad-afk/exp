define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class AddDistributionButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     * @param {any} params.key
     * @param {number} params.index
     * @param {any} params.current
     */
    async run(context, { event, originalEvent, key, index, current }) {
      const { $page, $flow, $application, $constants, $variables } = context;


      const clickedRow = (current && current.row) || null;
      if (clickedRow) {
        $variables.lineIdVar = String(clickedRow.line_id != null ? clickedRow.line_id : '');
        $variables.statementLineAmountVar = String(clickedRow.entry_amt != null ? clickedRow.entry_amt : '');
      }


      let items = [];

      try {
        const response = await Actions.callRest(context, {
          endpoint: 'awaitingDistribution/get',
          queryParams: {
            'line_id': $variables.lineIdVar,
          },
        });

        const body = response.body || response;
        items = (body && body.items) || [];

      } catch (error) {
        items = [];
      }

      const currentData = [];

      if (items.length > 0) {

        $variables.hasAwaitingDistVar = true;

        items.forEach((item, itemIndex) => {
          currentData.push({
            rowKey: 'r' + (itemIndex + 1),
            selected: [],
            offsetDist: item.je_output_string || '',
            offsetRaw: '',
            amount: item.distribution_amt,
            description: item.journal_description || '',
            status: 'Awaiting Approval',
            await_distribution_id: item.await_distribution_id,
            line_id: item.line_id,
          });
        });

      } else {

        $variables.hasAwaitingDistVar = false;

      }

      $variables.distributionRows = currentData;

      await Actions.callChain(context, { chain: 'refreshAmountActionChain', });

      // await Actions.fireDataProviderEvent(context, {
      //   refresh: null,
      //   target: $variables.addDistributionADP,
      // });

      const addDistributionsDialogOpen = await Actions.callComponentMethod(context, {
        selector: '#addDistributionsDialog',
        method: 'open',
      });

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.listDocumentsSDP,
      });
    }
  }

  return AddDistributionButtonActionChain;
});