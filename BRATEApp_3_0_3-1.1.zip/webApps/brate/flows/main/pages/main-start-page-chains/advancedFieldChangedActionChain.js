define([
  'vb/action/actionChain',
  'vb/action/actions',
], (ActionChain, Actions) => {
  'use strict';

  class advancedFieldChangedActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.value
     */
    async run(context, { value }) {
      const { $variables } = context;

      if (value === undefined || value === null || value === '') {
        return;
      }

      const options = Array.isArray($variables.advancedFieldOptionsData)
        ? $variables.advancedFieldOptionsData
        : [];

      const match = options.find((option) => option && option.value === value);

      if (!match || !match.field) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Field Not Recognised',
          message: 'No advanced search field is mapped to "' + value + '".',
          type: 'error',
          displayMode: 'transient',
        });
        $variables.advancedFieldVar = '';
        return;
      }

      const next = Object.assign({}, $variables.advancedSearchVar);
      next[match.field] = true;
      $variables.advancedSearchVar = next;

      $variables.advancedFieldVar = '';
    }
  }

  return advancedFieldChangedActionChain;
});
