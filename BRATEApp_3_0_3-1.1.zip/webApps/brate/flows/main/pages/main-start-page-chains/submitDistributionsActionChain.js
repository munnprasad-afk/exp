define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (ActionChain, Actions, ActionUtils) => {
  'use strict';

  class submitDistributionsActionChain extends ActionChain {

    async run(context, { event, originalEvent }) {
      const { $page, $variables } = context;





      const rows = Array.isArray($variables.distributionRows)
        ? $variables.distributionRows
        : [];

      if (rows.length === 0) {
        await Actions.fireNotificationEvent(context, {
          summary: 'No Distributions',
          message: 'Add at least one distribution row before submitting.',
          type: 'warning',
          displayMode: 'transient',
        });
        return;
      }

      // Validate required fields
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        if (!row.offsetDist || String(row.offsetDist).trim() === '') {
          await Actions.fireNotificationEvent(context, {
            summary: 'Validation Error - Row ' + (i + 1),
            message: 'Offset Distributions is required.',
            type: 'error',
            displayMode: 'transient',
          });
          return;
        }
        if (row.amount === null || row.amount === undefined || String(row.amount).trim() === '') {
          await Actions.fireNotificationEvent(context, {
            summary: 'Validation Error - Row ' + (i + 1),
            message: 'Distribution Amount is required.',
            type: 'error',
            displayMode: 'transient',
          });
          return;
        }
      }

      // Validate sum equals statement line amount
      const statementAmt = Math.round((parseFloat($variables.statementLineAmountVar) || 0) * 100) / 100;
      const totalDistributed = Math.round(
        rows.reduce((sum, row) => sum + (parseFloat(row.amount) || 0), 0) * 100
      ) / 100;

      if (totalDistributed !== statementAmt) {
        const remaining = Math.round((statementAmt - totalDistributed) * 100) / 100;
        const direction = totalDistributed > statementAmt ? 'exceeds' : 'is less than';
        await Actions.fireNotificationEvent(context, {
          summary: 'Amount Mismatch',
          message: 'Total distributed (' + totalDistributed + ') ' + direction
            + ' Statement Line Amount (' + statementAmt + '). Difference: ' + Math.abs(remaining) + '.',
          type: 'error',
          displayMode: 'transient',
        });
        return;
      }

      await Actions.callChain(context, {
        chain: 'SaveButtonActionChain',
      });
      

      let allSuccess = true;
        $variables.addDistributionInProgress = true;



// Map the entire UI rows array into the clean JSON payload format
const bulkPayload = rows.map((row) => {
  return {
    line_id: Number($variables.lineIdVar),
    je_output_string: row.offsetDist,
    distribution_amt: Number(row.amount),
    created_by: $variables.createdByUser,
    journal_description: row.description || '',
  };
});

try {
  // Call the REST endpoint exactly once with the complete array payload
  const response = await Actions.callRest(context, {
    endpoint: 'addDistributions/post',
    body: bulkPayload,
  });

  // Handle response criteria
  if (!response.ok) {
    allSuccess = false;
    await Actions.fireNotificationEvent(context, {
      summary: 'Distributions Submission Failed',
      message: response.body?.message || '.',
      type: 'error',
      displayMode: 'transient',
    });
  } else {
    // Proactively notify the user using the row count returned from your ORDS backend
    await Actions.fireNotificationEvent(context, {
      summary: 'Distributions Submitted',
      message: response.body?.message || 'Distributions Submitted successfully.',
      type: 'info',
      displayMode: 'transient',
    });
  }
} catch (error) {
  allSuccess = false;
  await Actions.fireNotificationEvent(context, {
    summary: 'Distributions Submission Error',
    message: (error && error.message) ? error.message : 'Unexpected error.',
    type: 'error',
    displayMode: 'transient',
  });
}



      if (allSuccess) {



      const response2 = await Actions.callRest(context, {
        endpoint: 'getTransactionId/get',
        uriParams: {
          'line_id': $variables.lineIdVar,
        },
      });

      $variables.transactionIdvar = response2.body.items[0].transactionid;

            const addDistributionsDialogClose = await Actions.callComponentMethod(context, {
        selector: '#addDistributionsDialog',
        method: 'close',
      });

        $variables.distributionRows = [];



 const approvalTriggerbody = {
    submittedBy: $page.variables.createdByUser,
    transactionType: "DistApproval",
    transactionId: $page.variables.transactionIdvar,
  
};

        const response3 = await Actions.callRest(context, {
          endpoint: 'TransactionUIApprovalTrigger/postTRANSACTIONUIAPPROVALTRIGGER1_0TriggerApproval',
          body:approvalTriggerbody,
        });
      }

      $variables.addDistributionInProgress = false;
    }
  }

  return submitDistributionsActionChain;
});
