define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class resetButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      await Actions.resetVariables(context, {
        variables: [
    '$variables.toDateVar',
    '$variables.glStatusVar',
    '$variables.fromDateVar',
    '$variables.bankNameVar',
    '$variables.bankAccountVar',
    '$variables.bankAccountNameVar',
    '$variables.amountVar',
'$variables.amountcurrencyVar',
'$variables.baicodeVar',
'$variables.cashglaccountVar',
'$variables.classificationVar',
'$variables.classificationruleidVar',
'$variables.classificationrulenameVar',
'$variables.classificationruleversionVar',
'$variables.closingbalanceVar',
'$variables.companycodeVar',
'$variables.customerreferenceVar',
'$variables.descriptionVar',
'$variables.domaincodeVar',
'$variables.exchangeamountVar',
'$variables.exchangecurrencyVar',
'$variables.exchangerateVar',
'$variables.exchangeratedateVar',
'$variables.familycodeVar',
'$variables.filenameVar',
'$variables.glaccountVar',
'$variables.glflagVar',
'$variables.headermessageVar',
'$variables.headeridVar',
'$variables.jegroupVar',
'$variables.jereversalreasonVar',
'$variables.jereversalstatusVar',
'$variables.journalizationruleidVar',
'$variables.journalizationrulenameVar',
'$variables.journalizationruleversionVar',
'$variables.lastupdatedateVar',
'$variables.lastupdatedbyVar',
'$variables.ledgernameVar',
'$variables.linemessageVar',
'$variables.linenumberVar',
'$variables.lineidVar',
'$variables.manualoverrideVar',
'$variables.numberofcreditentriesVar',
'$variables.numberofdebitentriesVar',
'$variables.offseticcreditVar',
'$variables.offseticdebitVar',
'$variables.offsetledgerVar',
'$variables.openingbalanceVar',
'$variables.oraclecetransferVar',
'$variables.reconciledamountVar',
'$variables.reconciliationstatusVar',
'$variables.statementnumberVar',
'$variables.subfamilycodeVar',
'$variables.transactiontypeVar',
'$variables.trxentrynoVar'

  ],
      });

      $variables.columnViewVar = 'default';

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $variables.hdrlinedataSDP,
      });
    }
  }

  return resetButtonActionChain;
});
