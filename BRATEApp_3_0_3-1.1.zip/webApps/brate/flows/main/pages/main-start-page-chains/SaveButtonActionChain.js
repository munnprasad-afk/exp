define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SaveButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object} params.event
     * @param {any} params.originalEvent
     */
    async run(context, { event, originalEvent }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      // 0. If a row is still in edit mode, force-commit it first.
      //    Clicking Save while editing means beforeRowEditEnd has not run yet,
      //    so the BDP buffer would still be empty at this point.
      //    Requires id="resultsTable" on the main oj-table.
      const table = document.getElementById('resultsTable');
      if (table && table.editRow && table.editRow.rowKey !== null && table.editRow.rowKey !== undefined) {
        table.editRow = { rowKey: null }; // triggers beforeRowEditEnd -> updateItem

        // Wait until the edit-end chain has pushed the change into the buffer
        for (let i = 0; i < 10; i++) {
          await new Promise((resolve) => setTimeout(resolve, 50));
          const buffered = await $page.variables.hdrlinedataBDP.instance.getSubmittableItems();
          if (buffered.length > 0) {
            break;
          }
        }
      }

      // 1. Get the submitted items from BDP memory
      const submittableItems = await $page.variables.hdrlinedataBDP.instance.getSubmittableItems();

      if (submittableItems.length === 0) {
        await Actions.fireNotificationEvent(context, {
          summary: 'No Changes',
          message: 'There are no edits to save for Classification/JE Grouping.',
          type: 'warning',
          displayMode: 'transient',
        });
        return;
      }

      // A record is only updatable if it ORIGINALLY has a line_id
      const hasLineId = (data) =>
        data &&
        data.line_id !== undefined &&
        data.line_id !== null &&
        String(data.line_id).trim() !== '';

      // Normalize values so both keys are always present in the body.
      // undefined / null -> '' (Oracle binds '' as NULL), else trimmed string.
      const norm = (v) => (v === undefined || v === null) ? '' : String(v).trim();

      await ActionUtils.forEach(submittableItems, async (row) => {

        // GUARD: skip any record without a Line Id - do not send the update
        if (!hasLineId(row.item.data)) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Record Skipped - Missing Line Id',
            type: 'warning',
            displayMode: 'transient',
            message: 'This record has no Line Id and cannot be updated.'
              + ' (Statement: ' + norm(row.item.data && row.item.data.statement_number)
              + ', Account: ' + norm(row.item.data && row.item.data.bank_account_num) + ')',
          });
          return;
        }

        const lineId = row.item.data.line_id;
        const body = {
          classification: norm(row.item.data.classification),
          je_grouping: norm(row.item.data.je_grouping),
        };

        try {
          const response = await Actions.callRest(context, {
            endpoint: 'updtJeClassification/update',
            uriParams: {
              'line_id': lineId,
            },
            body: body,
          });

          if (!response.ok) {
            await Actions.fireNotificationEvent(context, {
              summary: 'Line Id Update Failed  for Classification/JE Grouping : ' + lineId,
              type: 'error',
              displayMode: 'transient',
              message: 'JE Grouping : ' + body.je_grouping + ' | Classification : ' + body.classification,
            });
            return;
          }

          await Actions.fireNotificationEvent(context, {
            summary: 'Line ID Updated Successfully for Classification/JE Grouping : ' + lineId,
            type: 'confirmation',
            displayMode: 'transient',
            message: 'JE Grouping : ' + body.je_grouping + ' | Classification : ' + body.classification,
          });

        } catch (error) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Line Id Update Error for Classification/JE Grouping : ' + lineId,
            type: 'error',
            displayMode: 'transient',
            message: (error && error.message) ? error.message : 'Unexpected error calling update service.',
          });
        }

      }, { mode: 'serial' });

      await Actions.resetVariables(context, {
        variables: [
          '$variables.hdrlinedataBDP',
        ],
      });
    }
  }

  return SaveButtonActionChain;
});